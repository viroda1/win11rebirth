'use client'

import { useState, useEffect } from 'react'
import { useOSStore } from '@/lib/store'
import { Lock, ArrowRight, User, Github, Globe } from 'lucide-react'

export function LoginScreen() {
  const { login, user, isLocked, unlock } = useOSStore()
  const [username, setUsername] = useState(user?.username || '')
  const [password, setPassword] = useState('')
  const [showLogin, setShowLogin] = useState(false)
  const [time, setTime] = useState(new Date())
  const [error, setError] = useState('')

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  const handleUnlock = () => {
    if (user && isLocked) {
      // Just unlock for existing user
      unlock()
      return
    }
    setShowLogin(true)
  }

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (!username.trim()) {
      setError('Please enter a username')
      return
    }
    // Simple password check (demo purposes)
    if (password !== '' && password !== 'rebirth') {
      setError('Invalid password (hint: leave empty or use "rebirth")')
      return
    }
    login(username.trim())
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    })
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
    })
  }

  if (isLocked && user) {
    // Lock screen for logged in user
    return (
      <div className="fixed inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-[#1a0a2e] via-[#16082a] to-[#0d0515]">
        {/* Animated background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-primary/20 blur-3xl animate-pulse" />
          <div className="absolute -bottom-40 -left-40 h-80 w-80 rounded-full bg-accent/20 blur-3xl animate-pulse delay-1000" />
        </div>

        <div className="relative z-10 flex flex-col items-center gap-6 text-center">
          <div className="text-7xl font-light tracking-tight text-foreground glow-text">
            {formatTime(time)}
          </div>
          <div className="text-xl text-muted-foreground">
            {formatDate(time)}
          </div>

          <button
            onClick={handleUnlock}
            className="mt-12 flex flex-col items-center gap-4 group cursor-pointer"
          >
            <div className="flex h-32 w-32 items-center justify-center rounded-full glass glow transition-transform group-hover:scale-105">
              <span className="text-5xl">{user.avatar}</span>
            </div>
            <span className="text-xl font-medium text-foreground">{user.username}</span>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Lock className="h-4 w-4" />
              <span>Click to unlock</span>
            </div>
          </button>
        </div>

        <div className="absolute bottom-8 text-center text-sm text-muted-foreground">
          <div className="flex items-center gap-2 justify-center">
            <span>Win11 Rebirth</span>
            <span className="text-primary">by v/admin</span>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-[#1a0a2e] via-[#16082a] to-[#0d0515]">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-primary/20 blur-3xl animate-pulse" />
        <div className="absolute -bottom-40 -left-40 h-80 w-80 rounded-full bg-accent/20 blur-3xl animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-96 w-96 rounded-full bg-primary/10 blur-3xl" />
      </div>

      {!showLogin ? (
        <div className="relative z-10 flex flex-col items-center gap-6 text-center">
          <div className="text-8xl font-light tracking-tight text-foreground glow-text">
            {formatTime(time)}
          </div>
          <div className="text-2xl text-muted-foreground">
            {formatDate(time)}
          </div>

          <button
            onClick={handleUnlock}
            className="mt-16 flex flex-col items-center gap-4 group cursor-pointer transition-all hover:translate-y-[-4px]"
          >
            <div className="flex h-24 w-24 items-center justify-center rounded-full glass glow">
              <User className="h-12 w-12 text-primary" />
            </div>
            <div className="flex items-center gap-2 text-muted-foreground group-hover:text-foreground transition-colors">
              <span>Click to sign in</span>
              <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </button>
        </div>
      ) : (
        <div className="relative z-10 flex flex-col items-center gap-8">
          {/* Logo */}
          <div className="flex flex-col items-center gap-4">
            <div className="flex h-20 w-20 items-center justify-center rounded-2xl glass glow">
              <div className="text-3xl font-bold text-primary">W11</div>
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">Win11 Rebirth</h1>
              <p className="text-center text-muted-foreground mt-1">by v/admin (viroda1)</p>
            </div>
          </div>

          {/* Login form */}
          <form onSubmit={handleLogin} className="flex flex-col gap-4 w-80">
            <div className="flex flex-col gap-2">
              <label className="text-sm text-muted-foreground">Username</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your name"
                  className="w-full rounded-lg glass px-10 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  autoFocus
                />
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <label className="text-sm text-muted-foreground">Password (optional)</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Leave empty or use 'rebirth'"
                  className="w-full rounded-lg glass px-10 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>

            {error && (
              <p className="text-sm text-destructive text-center">{error}</p>
            )}

            <button
              type="submit"
              className="flex items-center justify-center gap-2 rounded-lg bg-primary py-3 text-primary-foreground font-medium transition-all hover:bg-primary/90 hover:glow"
            >
              <span>Sign In</span>
              <ArrowRight className="h-5 w-5" />
            </button>

            <button
              type="button"
              onClick={() => setShowLogin(false)}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              Back
            </button>
          </form>

          {/* Links */}
          <div className="flex items-center gap-6 text-sm text-muted-foreground">
            <a
              href="https://github.com/viroda1"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 hover:text-primary transition-colors"
            >
              <Github className="h-4 w-4" />
              <span>GitHub</span>
            </a>
            <a
              href="https://vironexus.rf.gd"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 hover:text-primary transition-colors"
            >
              <Globe className="h-4 w-4" />
              <span>ViroNexus</span>
            </a>
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="absolute bottom-8 text-center text-sm text-muted-foreground">
        <div className="flex items-center gap-4 justify-center">
          <span>Win11 Rebirth v1.0</span>
          <span className="text-primary">Powered by ViroNexus</span>
        </div>
      </div>
    </div>
  )
}
