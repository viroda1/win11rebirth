'use client'

import { useEffect, useState } from 'react'
import { useOSStore } from '@/lib/store'
import {
  Search,
  LayoutGrid,
  Wifi,
  WifiOff,
  Volume2,
  VolumeX,
  Battery,
  ChevronUp,
  Folder,
  Globe,
  Terminal,
  Settings,
  ShoppingBag,
  Mail,
} from 'lucide-react'
import { apps } from '@/lib/apps'

const taskbarIconMap: Record<string, React.ReactNode> = {
  'folder': <Folder className="w-5 h-5" />,
  'globe': <Globe className="w-5 h-5" />,
  'terminal': <Terminal className="w-5 h-5" />,
  'settings': <Settings className="w-5 h-5" />,
  'store': <ShoppingBag className="w-5 h-5" />,
  'mail': <Mail className="w-5 h-5" />,
}

export function Taskbar() {
  const {
    windows,
    activeWindowId,
    startMenuOpen,
    toggleStartMenu,
    focusWindow,
    minimizeWindow,
    restoreWindow,
    toggleNotificationCenter,
    notificationCenterOpen,
    toggleSearch,
    toggleWidgets,
    volume,
    wifi,
  } = useOSStore()

  const [time, setTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    })
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    })
  }

  const handleTaskbarClick = (windowId: string) => {
    const window = windows.find(w => w.id === windowId)
    if (window) {
      if (window.id === activeWindowId && !window.isMinimized) {
        minimizeWindow(windowId)
      } else if (window.isMinimized) {
        restoreWindow(windowId)
        focusWindow(windowId)
      } else {
        focusWindow(windowId)
      }
    }
  }

  const pinnedApps = [
    apps.find(a => a.id === 'file-explorer'),
    apps.find(a => a.id === 'browser'),
    apps.find(a => a.id === 'terminal'),
    apps.find(a => a.id === 'store'),
    apps.find(a => a.id === 'mail'),
    apps.find(a => a.id === 'settings'),
  ].filter(Boolean)

  return (
    <div className="fixed bottom-0 left-0 right-0 h-12 glass z-50 flex items-center justify-between px-2">
      {/* Left section - Widgets */}
      <div className="flex items-center">
        <button
          onClick={toggleWidgets}
          className="taskbar-icon flex h-10 w-10 items-center justify-center rounded-lg hover:bg-secondary/50 transition-colors"
          title="Widgets"
        >
          <LayoutGrid className="h-5 w-5 text-muted-foreground" />
        </button>
      </div>

      {/* Center section - Start, Search, Pinned Apps */}
      <div className="flex items-center gap-1">
        {/* Start button */}
        <button
          onClick={toggleStartMenu}
          className={`taskbar-icon flex h-10 w-10 items-center justify-center rounded-lg transition-colors ${
            startMenuOpen ? 'bg-secondary' : 'hover:bg-secondary/50'
          }`}
          title="Start"
        >
          <div className="flex h-6 w-6 items-center justify-center">
            <svg viewBox="0 0 24 24" className="h-5 w-5 text-primary" fill="currentColor">
              <path d="M3 3h8v8H3V3zm10 0h8v8h-8V3zM3 13h8v8H3v-8zm10 0h8v8h-8v-8z" />
            </svg>
          </div>
        </button>

        {/* Search button */}
        <button
          onClick={toggleSearch}
          className="taskbar-icon flex h-10 w-10 items-center justify-center rounded-lg hover:bg-secondary/50 transition-colors"
          title="Search"
        >
          <Search className="h-5 w-5 text-muted-foreground" />
        </button>

        {/* Divider */}
        <div className="mx-2 h-6 w-px bg-border" />

        {/* Pinned apps */}
        {pinnedApps.map((app) => app && (
          <button
            key={app.id}
            onClick={() => {
              const { openWindow } = useOSStore.getState()
              openWindow(app)
            }}
            className="taskbar-icon flex h-10 w-10 items-center justify-center rounded-lg hover:bg-secondary/50 transition-colors text-purple-400 hover:text-purple-300"
            title={app.title}
          >
            {taskbarIconMap[app.icon] || <Folder className="w-5 h-5" />}
          </button>
        ))}

        {/* Divider */}
        {windows.length > 0 && <div className="mx-2 h-6 w-px bg-border" />}

        {/* Open windows */}
        {windows.map((window) => (
          <button
            key={window.id}
            onClick={() => handleTaskbarClick(window.id)}
            className={`taskbar-icon relative flex h-10 min-w-10 items-center justify-center gap-2 rounded-lg px-2 transition-colors text-purple-400 ${
              window.id === activeWindowId && !window.isMinimized
                ? 'bg-secondary'
                : 'hover:bg-secondary/50'
            }`}
            title={window.title}
          >
            {taskbarIconMap[window.icon] || <Folder className="w-5 h-5" />}
            {/* Active indicator */}
            <div
              className={`absolute bottom-1 h-0.5 w-4 rounded-full transition-all ${
                window.id === activeWindowId && !window.isMinimized
                  ? 'bg-primary'
                  : window.isMinimized
                  ? 'bg-muted-foreground/50'
                  : 'bg-muted-foreground'
              }`}
            />
          </button>
        ))}
      </div>

      {/* Right section - System tray */}
      <div className="flex items-center gap-1">
        {/* Hidden icons */}
        <button className="taskbar-icon flex h-8 w-8 items-center justify-center rounded hover:bg-secondary/50 transition-colors">
          <ChevronUp className="h-4 w-4 text-muted-foreground" />
        </button>

        {/* System icons */}
        <button
          onClick={toggleNotificationCenter}
          className={`taskbar-icon flex items-center gap-2 rounded-lg px-2 py-1 transition-colors ${
            notificationCenterOpen ? 'bg-secondary' : 'hover:bg-secondary/50'
          }`}
        >
          {wifi ? (
            <Wifi className="h-4 w-4 text-muted-foreground" />
          ) : (
            <WifiOff className="h-4 w-4 text-muted-foreground" />
          )}
          {volume > 0 ? (
            <Volume2 className="h-4 w-4 text-muted-foreground" />
          ) : (
            <VolumeX className="h-4 w-4 text-muted-foreground" />
          )}
          <Battery className="h-4 w-4 text-muted-foreground" />
        </button>

        {/* Date & Time */}
        <button
          onClick={toggleNotificationCenter}
          className={`taskbar-icon flex flex-col items-end rounded-lg px-2 py-1 transition-colors ${
            notificationCenterOpen ? 'bg-secondary' : 'hover:bg-secondary/50'
          }`}
        >
          <span className="text-xs text-foreground">{formatTime(time)}</span>
          <span className="text-xs text-muted-foreground">{formatDate(time)}</span>
        </button>

        {/* Show desktop */}
        <div className="ml-1 h-10 w-1 rounded hover:bg-primary/50 transition-colors cursor-pointer" />
      </div>
    </div>
  )
}
