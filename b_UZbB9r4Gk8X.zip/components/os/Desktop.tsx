'use client'

import { useOSStore } from '@/lib/store'
import { apps } from '@/lib/apps'
import { Window } from './Window'
import { Taskbar } from './Taskbar'
import { StartMenu } from './StartMenu'
import { NotificationCenter } from './NotificationCenter'
import { SearchPanel } from './SearchPanel'
import { WidgetsPanel } from './WidgetsPanel'
import {
  Folder, Globe, Settings, Terminal as TerminalIcon, FileText,
  Calculator as CalcIcon, Music, Image, Info, ShoppingBag, Mail,
  Calendar, Cloud, Palette, Gamepad2
} from 'lucide-react'

// App Components
import { FileExplorer } from '../apps/FileExplorer'
import { Browser } from '../apps/Browser'
import { Settings as SettingsApp } from '../apps/Settings'
import { Terminal } from '../apps/Terminal'
import { Notepad } from '../apps/Notepad'
import { Calculator } from '../apps/Calculator'
import { MusicPlayer } from '../apps/MusicPlayer'
import { Photos } from '../apps/Photos'
import { About } from '../apps/About'
import Store from '../apps/Store'
import MailApp from '../apps/Mail'
import CalendarApp from '../apps/Calendar'
import Weather from '../apps/Weather'
import Paint from '../apps/Paint'
import Games from '../apps/Games'

const wallpapers = [
  'linear-gradient(135deg, #1a0a2e 0%, #16082a 50%, #0d0515 100%)',
  'linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%)',
  'linear-gradient(135deg, #1e1e2e 0%, #3e1f47 50%, #1a1a2e 100%)',
  'linear-gradient(135deg, #0a0a0f 0%, #1a0a2e 50%, #2d1b4e 100%)',
  'linear-gradient(135deg, #1a1c2e 0%, #2d1f54 50%, #0d0515 100%)',
]

const iconMap: Record<string, React.ReactNode> = {
  'folder': <Folder className="w-8 h-8" />,
  'globe': <Globe className="w-8 h-8" />,
  'settings': <Settings className="w-8 h-8" />,
  'terminal': <TerminalIcon className="w-8 h-8" />,
  'file-text': <FileText className="w-8 h-8" />,
  'calculator': <CalcIcon className="w-8 h-8" />,
  'music': <Music className="w-8 h-8" />,
  'image': <Image className="w-8 h-8" />,
  'info': <Info className="w-8 h-8" />,
  'store': <ShoppingBag className="w-8 h-8" />,
  'mail': <Mail className="w-8 h-8" />,
  'calendar': <Calendar className="w-8 h-8" />,
  'cloud': <Cloud className="w-8 h-8" />,
  'palette': <Palette className="w-8 h-8" />,
  'gamepad-2': <Gamepad2 className="w-8 h-8" />,
}

const AppRenderer = ({ component }: { component: string }) => {
  switch (component) {
    case 'FileExplorer':
      return <FileExplorer />
    case 'Browser':
      return <Browser />
    case 'Settings':
      return <SettingsApp />
    case 'Terminal':
      return <Terminal />
    case 'Notepad':
      return <Notepad />
    case 'Calculator':
      return <Calculator />
    case 'MusicPlayer':
      return <MusicPlayer />
    case 'Photos':
      return <Photos />
    case 'About':
      return <About />
    case 'Store':
      return <Store />
    case 'Mail':
      return <MailApp />
    case 'Calendar':
      return <CalendarApp />
    case 'Weather':
      return <Weather />
    case 'Paint':
      return <Paint />
    case 'Games':
      return <Games />
    default:
      return <div className="flex items-center justify-center h-full text-muted-foreground">App not found</div>
  }
}

export function Desktop() {
  const { windows, user, openWindow, closeStartMenu, closeNotificationCenter, closeSearch, closeWidgets } = useOSStore()

  const desktopApps = apps.slice(0, 8)
  const wallpaper = wallpapers[user?.wallpaper || 0]

  const handleDesktopClick = () => {
    closeStartMenu()
    closeNotificationCenter()
    closeSearch()
    closeWidgets()
  }

  return (
    <div
      className="fixed inset-0 overflow-hidden select-none"
      style={{ background: wallpaper }}
      onClick={handleDesktopClick}
    >
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-primary/10 blur-3xl animate-pulse" />
        <div className="absolute -bottom-40 -left-40 h-80 w-80 rounded-full bg-accent/10 blur-3xl animate-pulse delay-1000" />
        <div className="absolute top-1/3 right-1/4 h-64 w-64 rounded-full bg-primary/5 blur-3xl" />
      </div>

      {/* Desktop icons */}
      <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
        {desktopApps.map((app) => (
          <button
            key={app.id}
            onClick={(e) => {
              e.stopPropagation()
              openWindow(app)
            }}
            onDoubleClick={(e) => {
              e.stopPropagation()
              openWindow(app)
            }}
            className="flex flex-col items-center gap-1 p-2 rounded-lg w-20 hover:bg-secondary/50 transition-colors group"
          >
            <div className="text-purple-400 drop-shadow-lg group-hover:scale-110 transition-transform group-hover:text-purple-300">
              {iconMap[app.icon] || <Folder className="w-8 h-8" />}
            </div>
            <span className="text-xs text-foreground text-center leading-tight drop-shadow-md">
              {app.title}
            </span>
          </button>
        ))}
      </div>

      {/* Windows */}
      {windows.map((window) => (
        <Window key={window.id} window={window}>
          <AppRenderer component={window.component} />
        </Window>
      ))}

      {/* Start Menu */}
      <StartMenu />

      {/* Search Panel */}
      <SearchPanel />

      {/* Widgets Panel */}
      <WidgetsPanel />

      {/* Notification Center */}
      <NotificationCenter />

      {/* Taskbar */}
      <Taskbar />
    </div>
  )
}
