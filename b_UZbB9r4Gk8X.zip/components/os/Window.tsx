'use client'

import { useRef, useState, useEffect, type ReactNode } from 'react'
import { useOSStore, type Window as WindowType } from '@/lib/store'
import { X, Minus, Square, Copy } from 'lucide-react'

interface WindowProps {
  window: WindowType
  children: ReactNode
}

export function Window({ window, children }: WindowProps) {
  const {
    closeWindow,
    minimizeWindow,
    maximizeWindow,
    restoreWindow,
    focusWindow,
    updateWindowPosition,
    activeWindowId,
  } = useOSStore()

  const windowRef = useRef<HTMLDivElement>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [isResizing, setIsResizing] = useState(false)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })
  const [isClosing, setIsClosing] = useState(false)

  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('.window-controls')) return
    focusWindow(window.id)
  }

  const handleTitleBarMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('.window-controls')) return
    if (window.isMaximized) return
    
    setIsDragging(true)
    setDragOffset({
      x: e.clientX - window.position.x,
      y: e.clientY - window.position.y,
    })
    focusWindow(window.id)
  }

  const handleDoubleClick = () => {
    if (window.isMaximized) {
      restoreWindow(window.id)
    } else {
      maximizeWindow(window.id)
    }
  }

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        updateWindowPosition(window.id, {
          x: Math.max(0, e.clientX - dragOffset.x),
          y: Math.max(0, e.clientY - dragOffset.y),
        })
      }
    }

    const handleMouseUp = () => {
      setIsDragging(false)
      setIsResizing(false)
    }

    if (isDragging || isResizing) {
      document.addEventListener('mousemove', handleMouseMove)
      document.addEventListener('mouseup', handleMouseUp)
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
    }
  }, [isDragging, isResizing, dragOffset, window.id, updateWindowPosition])

  const handleClose = () => {
    setIsClosing(true)
    setTimeout(() => closeWindow(window.id), 150)
  }

  if (window.isMinimized) return null

  const isActive = activeWindowId === window.id

  return (
    <div
      ref={windowRef}
      className={`fixed overflow-hidden rounded-xl glass flex flex-col ${
        isClosing ? 'window-close' : 'window-open'
      } ${isActive ? 'ring-1 ring-primary/50' : ''}`}
      style={{
        left: window.isMaximized ? 0 : window.position.x,
        top: window.isMaximized ? 0 : window.position.y,
        width: window.isMaximized ? '100%' : window.size.width,
        height: window.isMaximized ? 'calc(100% - 48px)' : window.size.height,
        zIndex: window.zIndex,
      }}
      onMouseDown={handleMouseDown}
    >
      {/* Title bar */}
      <div
        className={`flex h-10 items-center justify-between px-3 select-none ${
          isActive ? 'bg-card/80' : 'bg-card/50'
        } ${window.isMaximized ? '' : 'cursor-move'}`}
        onMouseDown={handleTitleBarMouseDown}
        onDoubleClick={handleDoubleClick}
      >
        <div className="flex items-center gap-2">
          <span className="text-lg">{window.icon}</span>
          <span className="text-sm font-medium text-foreground truncate max-w-64">
            {window.title}
          </span>
        </div>

        <div className="window-controls flex items-center gap-1">
          <button
            onClick={() => minimizeWindow(window.id)}
            className="flex h-7 w-7 items-center justify-center rounded hover:bg-secondary transition-colors"
            title="Minimize"
          >
            <Minus className="h-4 w-4 text-muted-foreground" />
          </button>
          <button
            onClick={() =>
              window.isMaximized
                ? restoreWindow(window.id)
                : maximizeWindow(window.id)
            }
            className="flex h-7 w-7 items-center justify-center rounded hover:bg-secondary transition-colors"
            title={window.isMaximized ? 'Restore' : 'Maximize'}
          >
            {window.isMaximized ? (
              <Copy className="h-3.5 w-3.5 text-muted-foreground" />
            ) : (
              <Square className="h-3.5 w-3.5 text-muted-foreground" />
            )}
          </button>
          <button
            onClick={handleClose}
            className="flex h-7 w-7 items-center justify-center rounded hover:bg-destructive hover:text-destructive-foreground transition-colors"
            title="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto bg-background/95">{children}</div>

      {/* Resize handle */}
      {!window.isMaximized && (
        <div
          className="absolute bottom-0 right-0 h-4 w-4 cursor-nwse-resize"
          onMouseDown={(e) => {
            e.stopPropagation()
            setIsResizing(true)
          }}
        />
      )}
    </div>
  )
}
