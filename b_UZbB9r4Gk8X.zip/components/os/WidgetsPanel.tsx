'use client'

import { useEffect, useState } from 'react'
import { useOSStore } from '@/lib/store'
import { Cloud, Sun, CloudRain, Thermometer, Calendar, Clock, TrendingUp } from 'lucide-react'

export function WidgetsPanel() {
  const { widgetsOpen, closeWidgets, user } = useOSStore()
  const [time, setTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  if (!widgetsOpen) return null

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    })
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    })
  }

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-40"
        onClick={closeWidgets}
      />

      {/* Panel */}
      <div className="fixed bottom-14 left-2 w-80 rounded-xl glass z-50 overflow-hidden start-menu-open max-h-[calc(100vh-80px)] overflow-y-auto">
        {/* Header */}
        <div className="p-4 border-b border-border">
          <h2 className="text-lg font-semibold text-foreground">Widgets</h2>
          <p className="text-sm text-muted-foreground">
            Good {time.getHours() < 12 ? 'morning' : time.getHours() < 18 ? 'afternoon' : 'evening'}, {user?.username || 'User'}!
          </p>
        </div>

        {/* Clock widget */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-3 mb-2">
            <Clock className="h-5 w-5 text-primary" />
            <span className="text-sm font-medium text-foreground">Clock</span>
          </div>
          <div className="text-center py-4 rounded-lg bg-secondary">
            <div className="text-3xl font-light text-foreground glow-text">
              {formatTime(time)}
            </div>
            <div className="text-sm text-muted-foreground mt-1">
              {formatDate(time)}
            </div>
          </div>
        </div>

        {/* Weather widget */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-3 mb-2">
            <Cloud className="h-5 w-5 text-primary" />
            <span className="text-sm font-medium text-foreground">Weather</span>
          </div>
          <div className="rounded-lg bg-secondary p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-4xl font-light text-foreground">22°</div>
                <div className="text-sm text-muted-foreground">Partly Cloudy</div>
              </div>
              <Sun className="h-12 w-12 text-yellow-400" />
            </div>
            <div className="flex items-center gap-4 mt-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Thermometer className="h-4 w-4" />
                <span>H: 25° L: 18°</span>
              </div>
            </div>
          </div>
        </div>

        {/* Calendar widget */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-3 mb-2">
            <Calendar className="h-5 w-5 text-primary" />
            <span className="text-sm font-medium text-foreground">Calendar</span>
          </div>
          <div className="rounded-lg bg-secondary p-4">
            <div className="text-sm text-muted-foreground mb-2">Upcoming</div>
            <div className="space-y-2">
              <div className="flex items-center gap-3 p-2 rounded bg-background/50">
                <div className="h-2 w-2 rounded-full bg-primary" />
                <div>
                  <div className="text-sm text-foreground">Team Meeting</div>
                  <div className="text-xs text-muted-foreground">10:00 AM</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-2 rounded bg-background/50">
                <div className="h-2 w-2 rounded-full bg-accent" />
                <div>
                  <div className="text-sm text-foreground">Lunch Break</div>
                  <div className="text-xs text-muted-foreground">12:00 PM</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick stats */}
        <div className="p-4">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            <span className="text-sm font-medium text-foreground">System</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-lg bg-secondary p-3 text-center">
              <div className="text-2xl font-semibold text-primary">12%</div>
              <div className="text-xs text-muted-foreground">CPU</div>
            </div>
            <div className="rounded-lg bg-secondary p-3 text-center">
              <div className="text-2xl font-semibold text-primary">45%</div>
              <div className="text-xs text-muted-foreground">RAM</div>
            </div>
            <div className="rounded-lg bg-secondary p-3 text-center">
              <div className="text-2xl font-semibold text-primary">234GB</div>
              <div className="text-xs text-muted-foreground">Storage</div>
            </div>
            <div className="rounded-lg bg-secondary p-3 text-center">
              <div className="text-2xl font-semibold text-primary">99%</div>
              <div className="text-xs text-muted-foreground">Battery</div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
