'use client'

import { useOSStore } from '@/lib/store'
import {
  Wifi,
  WifiOff,
  Bluetooth,
  BluetoothOff,
  Moon,
  Sun,
  Plane,
  Volume2,
  VolumeX,
  Battery,
  Focus,
  Cast,
  Accessibility,
} from 'lucide-react'

export function NotificationCenter() {
  const {
    notificationCenterOpen,
    closeNotificationCenter,
    wifi,
    bluetooth,
    volume,
    brightness,
    toggleWifi,
    toggleBluetooth,
    setVolume,
    setBrightness,
  } = useOSStore()

  if (!notificationCenterOpen) return null

  const quickActions = [
    {
      icon: wifi ? Wifi : WifiOff,
      label: 'Wi-Fi',
      active: wifi,
      onClick: toggleWifi,
    },
    {
      icon: bluetooth ? Bluetooth : BluetoothOff,
      label: 'Bluetooth',
      active: bluetooth,
      onClick: toggleBluetooth,
    },
    {
      icon: Plane,
      label: 'Airplane',
      active: false,
      onClick: () => {},
    },
    {
      icon: Moon,
      label: 'Night light',
      active: false,
      onClick: () => {},
    },
    {
      icon: Focus,
      label: 'Focus assist',
      active: false,
      onClick: () => {},
    },
    {
      icon: Cast,
      label: 'Project',
      active: false,
      onClick: () => {},
    },
  ]

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-40"
        onClick={closeNotificationCenter}
      />

      {/* Panel */}
      <div className="fixed bottom-14 right-2 w-80 rounded-xl glass z-50 overflow-hidden start-menu-open">
        {/* Quick actions */}
        <div className="p-3">
          <div className="grid grid-cols-3 gap-2">
            {quickActions.map((action) => (
              <button
                key={action.label}
                onClick={action.onClick}
                className={`flex flex-col items-center gap-2 rounded-lg p-3 transition-colors ${
                  action.active
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary hover:bg-secondary/80 text-foreground'
                }`}
              >
                <action.icon className="h-5 w-5" />
                <span className="text-xs">{action.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Sliders */}
        <div className="p-3 pt-0 space-y-4">
          {/* Brightness */}
          <div className="flex items-center gap-3">
            <Sun className="h-5 w-5 text-muted-foreground flex-shrink-0" />
            <input
              type="range"
              min="0"
              max="100"
              value={brightness}
              onChange={(e) => setBrightness(parseInt(e.target.value))}
              className="flex-1 h-1 bg-secondary rounded-full appearance-none cursor-pointer accent-primary"
            />
          </div>

          {/* Volume */}
          <div className="flex items-center gap-3">
            {volume > 0 ? (
              <Volume2 className="h-5 w-5 text-muted-foreground flex-shrink-0" />
            ) : (
              <VolumeX className="h-5 w-5 text-muted-foreground flex-shrink-0" />
            )}
            <input
              type="range"
              min="0"
              max="100"
              value={volume}
              onChange={(e) => setVolume(parseInt(e.target.value))}
              className="flex-1 h-1 bg-secondary rounded-full appearance-none cursor-pointer accent-primary"
            />
          </div>
        </div>

        {/* Battery */}
        <div className="p-3 pt-0">
          <div className="flex items-center justify-between rounded-lg bg-secondary p-3">
            <div className="flex items-center gap-3">
              <Battery className="h-5 w-5 text-muted-foreground" />
              <span className="text-sm text-foreground">Battery</span>
            </div>
            <span className="text-sm text-muted-foreground">100%</span>
          </div>
        </div>

        {/* Notifications */}
        <div className="border-t border-border p-3">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium text-foreground">Notifications</h3>
            <button className="text-xs text-primary hover:underline">
              Clear all
            </button>
          </div>
          <div className="space-y-2">
            <div className="rounded-lg bg-secondary p-3">
              <div className="flex items-start gap-3">
                <span className="text-xl">💜</span>
                <div>
                  <p className="text-sm font-medium text-foreground">Win11 Rebirth</p>
                  <p className="text-xs text-muted-foreground">
                    Welcome to Win11 Rebirth! Explore the new features.
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">Just now</p>
                </div>
              </div>
            </div>
            <div className="rounded-lg bg-secondary p-3">
              <div className="flex items-start gap-3">
                <span className="text-xl">🌐</span>
                <div>
                  <p className="text-sm font-medium text-foreground">ViroNexus</p>
                  <p className="text-xs text-muted-foreground">
                    Check out vironexus.rf.gd for more projects!
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">2 min ago</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
