'use client'

import { useState } from 'react'
import { useOSStore } from '@/lib/store'
import { apps } from '@/lib/apps'
import { 
  Power, Lock, Search, ChevronRight,
  Folder, Globe, Settings, Terminal, FileText,
  Calculator, Music, Image, Info, ShoppingBag, Mail,
  Calendar, Cloud, Palette, Gamepad2
} from 'lucide-react'

const iconMap: Record<string, React.ReactNode> = {
  'folder': <Folder className="w-6 h-6" />,
  'globe': <Globe className="w-6 h-6" />,
  'settings': <Settings className="w-6 h-6" />,
  'terminal': <Terminal className="w-6 h-6" />,
  'file-text': <FileText className="w-6 h-6" />,
  'calculator': <Calculator className="w-6 h-6" />,
  'music': <Music className="w-6 h-6" />,
  'image': <Image className="w-6 h-6" />,
  'info': <Info className="w-6 h-6" />,
  'store': <ShoppingBag className="w-6 h-6" />,
  'mail': <Mail className="w-6 h-6" />,
  'calendar': <Calendar className="w-6 h-6" />,
  'cloud': <Cloud className="w-6 h-6" />,
  'palette': <Palette className="w-6 h-6" />,
  'gamepad-2': <Gamepad2 className="w-6 h-6" />,
}

const smallIconMap: Record<string, React.ReactNode> = {
  'folder': <Folder className="w-5 h-5" />,
  'globe': <Globe className="w-5 h-5" />,
  'settings': <Settings className="w-5 h-5" />,
  'terminal': <Terminal className="w-5 h-5" />,
  'file-text': <FileText className="w-5 h-5" />,
  'calculator': <Calculator className="w-5 h-5" />,
  'music': <Music className="w-5 h-5" />,
  'image': <Image className="w-5 h-5" />,
  'info': <Info className="w-5 h-5" />,
  'store': <ShoppingBag className="w-5 h-5" />,
  'mail': <Mail className="w-5 h-5" />,
  'calendar': <Calendar className="w-5 h-5" />,
  'cloud': <Cloud className="w-5 h-5" />,
  'palette': <Palette className="w-5 h-5" />,
  'gamepad-2': <Gamepad2 className="w-5 h-5" />,
}

export function StartMenu() {
  const {
    startMenuOpen,
    closeStartMenu,
    openWindow,
    user,
    logout,
    lock,
  } = useOSStore()

  const [searchQuery, setSearchQuery] = useState('')

  if (!startMenuOpen) return null

  const filteredApps = searchQuery
    ? apps.filter(app =>
        app.title.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : apps

  const recommendedApps = apps.slice(0, 6)

  const handleAppClick = (app: typeof apps[0]) => {
    openWindow(app)
    closeStartMenu()
  }

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-40"
        onClick={closeStartMenu}
      />

      {/* Start menu */}
      <div className="fixed bottom-14 left-1/2 -translate-x-1/2 w-[640px] max-w-[calc(100vw-2rem)] rounded-xl glass z-50 overflow-hidden start-menu-open">
        {/* Search */}
        <div className="p-4 pb-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search apps, settings, and files"
              className="w-full rounded-full bg-secondary px-10 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              autoFocus
            />
          </div>
        </div>

        {searchQuery ? (
          /* Search results */
          <div className="p-4 pt-2">
            <h3 className="mb-3 text-sm font-medium text-muted-foreground">
              Search results
            </h3>
            <div className="grid grid-cols-4 gap-2">
              {filteredApps.map((app) => (
                <button
                  key={app.id}
                  onClick={() => handleAppClick(app)}
                  className="flex flex-col items-center gap-2 rounded-lg p-3 hover:bg-secondary transition-colors text-purple-400 hover:text-purple-300"
                >
                  {iconMap[app.icon] || <Folder className="w-6 h-6" />}
                  <span className="text-xs text-foreground text-center truncate w-full">
                    {app.title}
                  </span>
                </button>
              ))}
              {filteredApps.length === 0 && (
                <p className="col-span-4 text-center text-muted-foreground py-8">
                  No results found
                </p>
              )}
            </div>
          </div>
        ) : (
          <>
            {/* Pinned */}
            <div className="p-4 pt-2">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-medium text-foreground">Pinned</h3>
                <button className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors">
                  All apps
                  <ChevronRight className="h-3 w-3" />
                </button>
              </div>
              <div className="grid grid-cols-5 gap-2">
                {apps.map((app) => (
                  <button
                    key={app.id}
                    onClick={() => handleAppClick(app)}
                    className="flex flex-col items-center gap-2 rounded-lg p-3 hover:bg-secondary transition-colors text-purple-400 hover:text-purple-300"
                  >
                    {iconMap[app.icon] || <Folder className="w-6 h-6" />}
                    <span className="text-xs text-foreground text-center truncate w-full">
                      {app.title}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Recommended */}
            <div className="p-4 pt-0">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-medium text-foreground">Recommended</h3>
                <button className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors">
                  More
                  <ChevronRight className="h-3 w-3" />
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {recommendedApps.map((app) => (
                  <button
                    key={app.id}
                    onClick={() => handleAppClick(app)}
                    className="flex items-center gap-3 rounded-lg p-2 hover:bg-secondary transition-colors"
                  >
                    <div className="text-purple-400">
                      {smallIconMap[app.icon] || <Folder className="w-5 h-5" />}
                    </div>
                    <div className="text-left">
                      <span className="text-sm text-foreground block">{app.title}</span>
                      <span className="text-xs text-muted-foreground">Recently added</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-border p-3">
          <button className="flex items-center gap-3 rounded-lg px-3 py-2 hover:bg-secondary transition-colors">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-violet-600">
              <span className="text-lg">{user?.avatar || '👤'}</span>
            </div>
            <span className="text-sm font-medium text-foreground">
              {user?.username || 'User'}
            </span>
          </button>

          <div className="flex items-center gap-1">
            <button
              onClick={() => {
                lock()
                closeStartMenu()
              }}
              className="flex h-10 w-10 items-center justify-center rounded-lg hover:bg-secondary transition-colors"
              title="Lock"
            >
              <Lock className="h-5 w-5 text-muted-foreground" />
            </button>
            <button
              onClick={() => {
                logout()
                closeStartMenu()
              }}
              className="flex h-10 w-10 items-center justify-center rounded-lg hover:bg-secondary transition-colors"
              title="Sign out"
            >
              <Power className="h-5 w-5 text-muted-foreground" />
            </button>
          </div>
        </div>
      </div>
    </>
  )
}
