'use client'

import { useState } from 'react'
import { useOSStore } from '@/lib/store'
import { apps } from '@/lib/apps'
import { Search, Clock, TrendingUp } from 'lucide-react'

export function SearchPanel() {
  const { searchOpen, closeSearch, openWindow } = useOSStore()
  const [query, setQuery] = useState('')

  if (!searchOpen) return null

  const filteredApps = query
    ? apps.filter(app =>
        app.title.toLowerCase().includes(query.toLowerCase())
      )
    : []

  const topApps = apps.slice(0, 4)
  const recentSearches = ['Settings', 'Browser', 'Documents']

  const handleAppClick = (app: typeof apps[0]) => {
    openWindow(app)
    closeSearch()
    setQuery('')
  }

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-40"
        onClick={closeSearch}
      />

      {/* Panel */}
      <div className="fixed bottom-14 left-1/2 -translate-x-1/2 w-[600px] max-w-[calc(100vw-2rem)] rounded-xl glass z-50 overflow-hidden start-menu-open">
        {/* Search input */}
        <div className="p-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Type here to search"
              className="w-full rounded-full bg-secondary px-12 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              autoFocus
            />
          </div>
        </div>

        {query ? (
          /* Search results */
          <div className="p-4 pt-0">
            <h3 className="mb-3 text-sm font-medium text-muted-foreground">Apps</h3>
            {filteredApps.length > 0 ? (
              <div className="space-y-1">
                {filteredApps.map((app) => (
                  <button
                    key={app.id}
                    onClick={() => handleAppClick(app)}
                    className="flex items-center gap-3 w-full rounded-lg p-3 hover:bg-secondary transition-colors"
                  >
                    <span className="text-2xl">{app.icon}</span>
                    <div className="text-left">
                      <span className="text-sm font-medium text-foreground block">
                        {app.title}
                      </span>
                      <span className="text-xs text-muted-foreground capitalize">
                        {app.category}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">
                No results found for &quot;{query}&quot;
              </p>
            )}
          </div>
        ) : (
          <>
            {/* Top apps */}
            <div className="p-4 pt-0">
              <h3 className="mb-3 text-sm font-medium text-muted-foreground flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Top apps
              </h3>
              <div className="grid grid-cols-4 gap-2">
                {topApps.map((app) => (
                  <button
                    key={app.id}
                    onClick={() => handleAppClick(app)}
                    className="flex flex-col items-center gap-2 rounded-lg p-3 hover:bg-secondary transition-colors"
                  >
                    <span className="text-2xl">{app.icon}</span>
                    <span className="text-xs text-foreground text-center truncate w-full">
                      {app.title}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Recent searches */}
            <div className="p-4 pt-0">
              <h3 className="mb-3 text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Recent
              </h3>
              <div className="space-y-1">
                {recentSearches.map((search) => (
                  <button
                    key={search}
                    onClick={() => setQuery(search)}
                    className="flex items-center gap-3 w-full rounded-lg p-2 hover:bg-secondary transition-colors"
                  >
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-foreground">{search}</span>
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </>
  )
}
