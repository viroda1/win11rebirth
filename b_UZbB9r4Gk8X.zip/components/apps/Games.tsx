"use client"

import { useState, useEffect, useCallback } from 'react'
import { 
  Gamepad2, Trophy, ArrowLeft, RefreshCw, Star,
  ChevronUp, ChevronDown, ChevronLeft, ChevronRight
} from 'lucide-react'

type GameType = 'menu' | 'snake' | 'memory' | '2048'

interface MemoryCard {
  id: number
  value: string
  flipped: boolean
  matched: boolean
}

export default function Games() {
  const [currentGame, setCurrentGame] = useState<GameType>('menu')

  return (
    <div className="h-full bg-gradient-to-br from-[#0d0a12] to-[#1a1625] text-white">
      {currentGame === 'menu' && <GameMenu onSelect={setCurrentGame} />}
      {currentGame === 'snake' && <SnakeGame onBack={() => setCurrentGame('menu')} />}
      {currentGame === 'memory' && <MemoryGame onBack={() => setCurrentGame('menu')} />}
      {currentGame === '2048' && <Game2048 onBack={() => setCurrentGame('menu')} />}
    </div>
  )
}

function GameMenu({ onSelect }: { onSelect: (game: GameType) => void }) {
  const games = [
    { id: 'snake' as const, name: 'Snake', description: 'Classic snake game', icon: '🐍' },
    { id: 'memory' as const, name: 'Memory Match', description: 'Find matching pairs', icon: '🧠' },
    { id: '2048' as const, name: '2048', description: 'Slide and merge tiles', icon: '🎲' },
  ]

  return (
    <div className="h-full flex flex-col items-center justify-center p-8">
      <div className="text-center mb-8">
        <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-violet-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/30">
          <Gamepad2 className="w-10 h-10 text-white" />
        </div>
        <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-violet-300 bg-clip-text text-transparent">
          Rebirth Games
        </h1>
        <p className="text-gray-500 text-sm mt-1">Choose a game to play</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl w-full">
        {games.map(game => (
          <button
            key={game.id}
            onClick={() => onSelect(game.id)}
            className="bg-black/30 rounded-2xl p-6 border border-purple-500/20 hover:border-purple-500/50 transition-all hover:scale-105 text-left"
          >
            <div className="text-4xl mb-3">{game.icon}</div>
            <h3 className="font-bold text-lg">{game.name}</h3>
            <p className="text-sm text-gray-500">{game.description}</p>
          </button>
        ))}
      </div>
    </div>
  )
}

function SnakeGame({ onBack }: { onBack: () => void }) {
  const GRID_SIZE = 20
  const CELL_SIZE = 20
  const INITIAL_SPEED = 150

  const [snake, setSnake] = useState([{ x: 10, y: 10 }])
  const [food, setFood] = useState({ x: 15, y: 15 })
  const [direction, setDirection] = useState({ x: 1, y: 0 })
  const [gameOver, setGameOver] = useState(false)
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)
  const [isPaused, setIsPaused] = useState(false)

  const generateFood = useCallback(() => {
    let newFood
    do {
      newFood = {
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE),
      }
    } while (snake.some(s => s.x === newFood.x && s.y === newFood.y))
    return newFood
  }, [snake])

  const resetGame = () => {
    setSnake([{ x: 10, y: 10 }])
    setFood(generateFood())
    setDirection({ x: 1, y: 0 })
    setGameOver(false)
    setScore(0)
    setIsPaused(false)
  }

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameOver) return

      switch (e.key) {
        case 'ArrowUp':
          if (direction.y !== 1) setDirection({ x: 0, y: -1 })
          break
        case 'ArrowDown':
          if (direction.y !== -1) setDirection({ x: 0, y: 1 })
          break
        case 'ArrowLeft':
          if (direction.x !== 1) setDirection({ x: -1, y: 0 })
          break
        case 'ArrowRight':
          if (direction.x !== -1) setDirection({ x: 1, y: 0 })
          break
        case ' ':
          setIsPaused(p => !p)
          break
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [direction, gameOver])

  useEffect(() => {
    if (gameOver || isPaused) return

    const interval = setInterval(() => {
      setSnake(prev => {
        const newHead = {
          x: (prev[0].x + direction.x + GRID_SIZE) % GRID_SIZE,
          y: (prev[0].y + direction.y + GRID_SIZE) % GRID_SIZE,
        }

        // Check collision with self
        if (prev.some(s => s.x === newHead.x && s.y === newHead.y)) {
          setGameOver(true)
          if (score > highScore) setHighScore(score)
          return prev
        }

        const newSnake = [newHead, ...prev]

        // Check if food eaten
        if (newHead.x === food.x && newHead.y === food.y) {
          setFood(generateFood())
          setScore(s => s + 10)
        } else {
          newSnake.pop()
        }

        return newSnake
      })
    }, INITIAL_SPEED)

    return () => clearInterval(interval)
  }, [direction, food, gameOver, isPaused, generateFood, score, highScore])

  return (
    <div className="h-full flex flex-col items-center justify-center p-4">
      <div className="flex items-center justify-between w-full max-w-md mb-4">
        <button onClick={onBack} className="p-2 hover:bg-white/10 rounded-lg">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-4">
          <div className="text-center">
            <p className="text-xs text-gray-500">Score</p>
            <p className="font-bold text-purple-400">{score}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500">Best</p>
            <p className="font-bold text-yellow-400">{highScore}</p>
          </div>
        </div>
        <button onClick={resetGame} className="p-2 hover:bg-white/10 rounded-lg">
          <RefreshCw className="w-5 h-5" />
        </button>
      </div>

      <div 
        className="relative bg-black/50 rounded-xl border border-purple-500/30 overflow-hidden"
        style={{ width: GRID_SIZE * CELL_SIZE, height: GRID_SIZE * CELL_SIZE }}
      >
        {/* Food */}
        <div
          className="absolute bg-red-500 rounded-full"
          style={{
            width: CELL_SIZE - 2,
            height: CELL_SIZE - 2,
            left: food.x * CELL_SIZE + 1,
            top: food.y * CELL_SIZE + 1,
          }}
        />
        {/* Snake */}
        {snake.map((segment, i) => (
          <div
            key={i}
            className={`absolute rounded-sm ${i === 0 ? 'bg-purple-400' : 'bg-purple-500/80'}`}
            style={{
              width: CELL_SIZE - 2,
              height: CELL_SIZE - 2,
              left: segment.x * CELL_SIZE + 1,
              top: segment.y * CELL_SIZE + 1,
            }}
          />
        ))}

        {/* Game Over */}
        {gameOver && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center">
            <p className="text-xl font-bold mb-2">Game Over</p>
            <p className="text-gray-400 mb-4">Score: {score}</p>
            <button
              onClick={resetGame}
              className="px-4 py-2 bg-purple-500 hover:bg-purple-600 rounded-lg"
            >
              Play Again
            </button>
          </div>
        )}

        {isPaused && !gameOver && (
          <div className="absolute inset-0 bg-black/80 flex items-center justify-center">
            <p className="text-xl font-bold">Paused</p>
          </div>
        )}
      </div>

      <p className="text-xs text-gray-500 mt-4">Use arrow keys to move, space to pause</p>
    </div>
  )
}

function MemoryGame({ onBack }: { onBack: () => void }) {
  const EMOJIS = ['🎮', '🎲', '🎯', '🎪', '🎨', '🎭', '🎪', '🎸']
  
  const [cards, setCards] = useState<MemoryCard[]>([])
  const [flippedCards, setFlippedCards] = useState<number[]>([])
  const [moves, setMoves] = useState(0)
  const [matches, setMatches] = useState(0)
  const [bestMoves, setBestMoves] = useState(999)

  const initGame = useCallback(() => {
    const shuffled = [...EMOJIS, ...EMOJIS]
      .sort(() => Math.random() - 0.5)
      .map((value, i) => ({ id: i, value, flipped: false, matched: false }))
    setCards(shuffled)
    setFlippedCards([])
    setMoves(0)
    setMatches(0)
  }, [])

  useEffect(() => {
    initGame()
  }, [initGame])

  const flipCard = (id: number) => {
    if (flippedCards.length === 2) return
    if (cards[id].flipped || cards[id].matched) return

    const newCards = [...cards]
    newCards[id].flipped = true
    setCards(newCards)

    const newFlipped = [...flippedCards, id]
    setFlippedCards(newFlipped)

    if (newFlipped.length === 2) {
      setMoves(m => m + 1)
      
      if (cards[newFlipped[0]].value === cards[newFlipped[1]].value) {
        setTimeout(() => {
          const matched = [...cards]
          matched[newFlipped[0]].matched = true
          matched[newFlipped[1]].matched = true
          setCards(matched)
          setMatches(m => {
            const newMatches = m + 1
            if (newMatches === EMOJIS.length) {
              if (moves + 1 < bestMoves) setBestMoves(moves + 1)
            }
            return newMatches
          })
          setFlippedCards([])
        }, 500)
      } else {
        setTimeout(() => {
          const reset = [...cards]
          reset[newFlipped[0]].flipped = false
          reset[newFlipped[1]].flipped = false
          setCards(reset)
          setFlippedCards([])
        }, 1000)
      }
    }
  }

  const isComplete = matches === EMOJIS.length

  return (
    <div className="h-full flex flex-col items-center justify-center p-4">
      <div className="flex items-center justify-between w-full max-w-md mb-4">
        <button onClick={onBack} className="p-2 hover:bg-white/10 rounded-lg">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-4">
          <div className="text-center">
            <p className="text-xs text-gray-500">Moves</p>
            <p className="font-bold text-purple-400">{moves}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500">Best</p>
            <p className="font-bold text-yellow-400">{bestMoves === 999 ? '-' : bestMoves}</p>
          </div>
        </div>
        <button onClick={initGame} className="p-2 hover:bg-white/10 rounded-lg">
          <RefreshCw className="w-5 h-5" />
        </button>
      </div>

      <div className="grid grid-cols-4 gap-2 p-4 bg-black/30 rounded-xl border border-purple-500/20">
        {cards.map(card => (
          <button
            key={card.id}
            onClick={() => flipCard(card.id)}
            className={`w-16 h-16 rounded-lg text-2xl flex items-center justify-center transition-all duration-300 ${
              card.flipped || card.matched
                ? 'bg-purple-500/30 rotate-0'
                : 'bg-purple-900/50 hover:bg-purple-800/50'
            } ${card.matched ? 'opacity-50' : ''}`}
            disabled={card.matched}
          >
            {(card.flipped || card.matched) ? card.value : '?'}
          </button>
        ))}
      </div>

      {isComplete && (
        <div className="mt-4 text-center">
          <div className="flex items-center gap-2 text-yellow-400">
            <Trophy className="w-6 h-6" />
            <span className="font-bold">You Won!</span>
          </div>
          <p className="text-sm text-gray-400">Completed in {moves} moves</p>
        </div>
      )}
    </div>
  )
}

function Game2048({ onBack }: { onBack: () => void }) {
  const [grid, setGrid] = useState<number[][]>([])
  const [score, setScore] = useState(0)
  const [bestScore, setBestScore] = useState(0)
  const [gameOver, setGameOver] = useState(false)

  const initGame = useCallback(() => {
    const newGrid = Array(4).fill(null).map(() => Array(4).fill(0))
    addRandomTile(newGrid)
    addRandomTile(newGrid)
    setGrid(newGrid)
    setScore(0)
    setGameOver(false)
  }, [])

  useEffect(() => {
    initGame()
  }, [initGame])

  const addRandomTile = (g: number[][]) => {
    const empty: [number, number][] = []
    for (let i = 0; i < 4; i++) {
      for (let j = 0; j < 4; j++) {
        if (g[i][j] === 0) empty.push([i, j])
      }
    }
    if (empty.length > 0) {
      const [r, c] = empty[Math.floor(Math.random() * empty.length)]
      g[r][c] = Math.random() < 0.9 ? 2 : 4
    }
  }

  const move = useCallback((dir: 'up' | 'down' | 'left' | 'right') => {
    if (gameOver) return

    let newGrid = grid.map(row => [...row])
    let moved = false
    let newScore = score

    const slide = (arr: number[]) => {
      const filtered = arr.filter(x => x !== 0)
      const merged: number[] = []
      let i = 0
      while (i < filtered.length) {
        if (i + 1 < filtered.length && filtered[i] === filtered[i + 1]) {
          merged.push(filtered[i] * 2)
          newScore += filtered[i] * 2
          i += 2
        } else {
          merged.push(filtered[i])
          i++
        }
      }
      while (merged.length < 4) merged.push(0)
      return merged
    }

    if (dir === 'left') {
      for (let i = 0; i < 4; i++) {
        const newRow = slide(newGrid[i])
        if (newRow.join(',') !== newGrid[i].join(',')) moved = true
        newGrid[i] = newRow
      }
    } else if (dir === 'right') {
      for (let i = 0; i < 4; i++) {
        const newRow = slide([...newGrid[i]].reverse()).reverse()
        if (newRow.join(',') !== newGrid[i].join(',')) moved = true
        newGrid[i] = newRow
      }
    } else if (dir === 'up') {
      for (let j = 0; j < 4; j++) {
        const col = [newGrid[0][j], newGrid[1][j], newGrid[2][j], newGrid[3][j]]
        const newCol = slide(col)
        if (newCol.join(',') !== col.join(',')) moved = true
        for (let i = 0; i < 4; i++) newGrid[i][j] = newCol[i]
      }
    } else if (dir === 'down') {
      for (let j = 0; j < 4; j++) {
        const col = [newGrid[3][j], newGrid[2][j], newGrid[1][j], newGrid[0][j]]
        const newCol = slide(col)
        if (newCol.join(',') !== col.join(',')) moved = true
        for (let i = 0; i < 4; i++) newGrid[3 - i][j] = newCol[i]
      }
    }

    if (moved) {
      addRandomTile(newGrid)
      setGrid(newGrid)
      setScore(newScore)
      if (newScore > bestScore) setBestScore(newScore)

      // Check game over
      let canMove = false
      for (let i = 0; i < 4; i++) {
        for (let j = 0; j < 4; j++) {
          if (newGrid[i][j] === 0) canMove = true
          if (j < 3 && newGrid[i][j] === newGrid[i][j + 1]) canMove = true
          if (i < 3 && newGrid[i][j] === newGrid[i + 1][j]) canMove = true
        }
      }
      if (!canMove) setGameOver(true)
    }
  }, [grid, score, bestScore, gameOver])

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowUp': move('up'); break
        case 'ArrowDown': move('down'); break
        case 'ArrowLeft': move('left'); break
        case 'ArrowRight': move('right'); break
      }
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [move])

  const getTileColor = (value: number) => {
    const colors: Record<number, string> = {
      0: 'bg-gray-800/50',
      2: 'bg-gray-700',
      4: 'bg-gray-600',
      8: 'bg-orange-600',
      16: 'bg-orange-500',
      32: 'bg-red-500',
      64: 'bg-red-600',
      128: 'bg-yellow-500',
      256: 'bg-yellow-400',
      512: 'bg-purple-500',
      1024: 'bg-purple-400',
      2048: 'bg-purple-300',
    }
    return colors[value] || 'bg-purple-200'
  }

  return (
    <div className="h-full flex flex-col items-center justify-center p-4">
      <div className="flex items-center justify-between w-full max-w-xs mb-4">
        <button onClick={onBack} className="p-2 hover:bg-white/10 rounded-lg">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-4">
          <div className="text-center">
            <p className="text-xs text-gray-500">Score</p>
            <p className="font-bold text-purple-400">{score}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500">Best</p>
            <p className="font-bold text-yellow-400">{bestScore}</p>
          </div>
        </div>
        <button onClick={initGame} className="p-2 hover:bg-white/10 rounded-lg">
          <RefreshCw className="w-5 h-5" />
        </button>
      </div>

      <div className="bg-black/50 rounded-xl p-3 border border-purple-500/30">
        <div className="grid grid-cols-4 gap-2">
          {grid.map((row, i) =>
            row.map((cell, j) => (
              <div
                key={`${i}-${j}`}
                className={`w-16 h-16 rounded-lg flex items-center justify-center font-bold text-lg transition-all ${getTileColor(cell)}`}
              >
                {cell > 0 && cell}
              </div>
            ))
          )}
        </div>
      </div>

      {gameOver && (
        <div className="mt-4 text-center">
          <p className="font-bold text-red-400">Game Over!</p>
          <button
            onClick={initGame}
            className="mt-2 px-4 py-2 bg-purple-500 hover:bg-purple-600 rounded-lg"
          >
            Try Again
          </button>
        </div>
      )}

      <p className="text-xs text-gray-500 mt-4">Use arrow keys to move tiles</p>
    </div>
  )
}
