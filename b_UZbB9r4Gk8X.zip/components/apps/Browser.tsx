"use client"

import { useState, useRef, useEffect } from 'react'
import { 
  Globe, Plus, X, ArrowLeft, ArrowRight, RotateCw, Home, Star, 
  Lock, Shield, Download, Bookmark, History, Search,
  Puzzle, Trash2, Clock, Volume2, VolumeX, Moon, Zap, AlertCircle,
  Settings, Share2, Copy, ExternalLink, Maximize2, Image as ImageIcon
} from 'lucide-react'

interface Tab {
  id: string
  title: string
  url: string
  loading: boolean
  canGoBack: boolean
  canGoForward: boolean
  history: string[]
  historyIndex: number
  muted: boolean
}

interface BookmarkItem {
  id: string
  title: string
  url: string
}

interface HistoryItem {
  id: string
  title: string
  url: string
  visitedAt: Date
}

interface Extension {
  id: string
  name: string
  icon: React.ReactNode
  enabled: boolean
  description: string
}

const defaultExtensions: Extension[] = [
  { id: 'adblock', name: 'AdBlock Plus', icon: <Shield className="w-4 h-4" />, enabled: true, description: 'Block ads and trackers' },
  { id: 'darkmode', name: 'Dark Reader', icon: <Moon className="w-4 h-4" />, enabled: false, description: 'Dark mode for websites' },
  { id: 'speedup', name: 'Speed Boost', icon: <Zap className="w-4 h-4" />, enabled: true, description: 'Optimize page loading' },
]

const quickLinks = [
  { name: 'Google', url: 'https://www.google.com/webhp?igu=1' },
  { name: 'Wikipedia', url: 'https://en.wikipedia.org' },
  { name: 'DuckDuckGo', url: 'https://duckduckgo.com' },
  { name: 'Bing', url: 'https://www.bing.com' },
  { name: 'Archive.org', url: 'https://archive.org' },
  { name: 'ViroNexus', url: 'https://vironexus.rf.gd' },
]

export function Browser() {
  const [tabs, setTabs] = useState<Tab[]>([
    { 
      id: '1', 
      title: 'New Tab', 
      url: '', 
      loading: false,
      canGoBack: false,
      canGoForward: false,
      history: [''],
      historyIndex: 0,
      muted: false
    }
  ])
  const [activeTab, setActiveTab] = useState('1')
  const [urlInput, setUrlInput] = useState('')
  const [showBookmarks, setShowBookmarks] = useState(false)
  const [showHistory, setShowHistory] = useState(false)
  const [showExtensions, setShowExtensions] = useState(false)
  const [showDownloads, setShowDownloads] = useState(false)
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([
    { id: '1', title: 'Google', url: 'https://www.google.com/webhp?igu=1' },
    { id: '2', title: 'Wikipedia', url: 'https://en.wikipedia.org' },
  ])
  const [historyItems, setHistoryItems] = useState<HistoryItem[]>([])
  const [extensions, setExtensions] = useState<Extension[]>(defaultExtensions)
  const [downloads] = useState<{name: string, progress: number, done: boolean}[]>([])
  const [isSecure, setIsSecure] = useState(true)
  const iframeRef = useRef<HTMLIFrameElement>(null)

  const currentTab = tabs.find(t => t.id === activeTab)

  useEffect(() => {
    if (currentTab) {
      setUrlInput(currentTab.url)
      setIsSecure(currentTab.url.startsWith('https://') || currentTab.url === '')
    }
  }, [activeTab, currentTab?.url])

  const closeAllPanels = () => {
    setShowBookmarks(false)
    setShowHistory(false)
    setShowExtensions(false)
    setShowDownloads(false)
  }

  const createNewTab = () => {
    const newTab: Tab = {
      id: Date.now().toString(),
      title: 'New Tab',
      url: '',
      loading: false,
      canGoBack: false,
      canGoForward: false,
      history: [''],
      historyIndex: 0,
      muted: false
    }
    setTabs([...tabs, newTab])
    setActiveTab(newTab.id)
    setUrlInput('')
  }

  const closeTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    if (tabs.length === 1) {
      createNewTab()
    }
    const newTabs = tabs.filter(t => t.id !== id)
    setTabs(newTabs)
    if (activeTab === id && newTabs.length > 0) {
      setActiveTab(newTabs[newTabs.length - 1].id)
    }
  }

  const navigate = (url: string) => {
    let finalUrl = url.trim()
    
    if (!finalUrl) return

    if (!finalUrl.startsWith('http://') && !finalUrl.startsWith('https://')) {
      if (finalUrl.includes('.') && !finalUrl.includes(' ')) {
        finalUrl = 'https://' + finalUrl
      } else {
        finalUrl = `https://www.google.com/search?igu=1&q=${encodeURIComponent(finalUrl)}`
      }
    }

    setTabs(tabs.map(t => {
      if (t.id === activeTab) {
        const newHistory = [...t.history.slice(0, t.historyIndex + 1), finalUrl]
        return {
          ...t,
          url: finalUrl,
          loading: true,
          title: 'Loading...',
          history: newHistory,
          historyIndex: newHistory.length - 1,
          canGoBack: newHistory.length > 1,
          canGoForward: false
        }
      }
      return t
    }))

    setHistoryItems(prev => [{
      id: Date.now().toString(),
      title: finalUrl,
      url: finalUrl,
      visitedAt: new Date(),
    }, ...prev].slice(0, 100))

    setUrlInput(finalUrl)
  }

  const goBack = () => {
    if (!currentTab || currentTab.historyIndex <= 0) return
    
    setTabs(tabs.map(t => {
      if (t.id === activeTab) {
        const newIndex = t.historyIndex - 1
        return {
          ...t,
          url: t.history[newIndex],
          historyIndex: newIndex,
          canGoBack: newIndex > 0,
          canGoForward: true,
          loading: true
        }
      }
      return t
    }))
  }

  const goForward = () => {
    if (!currentTab || currentTab.historyIndex >= currentTab.history.length - 1) return
    
    setTabs(tabs.map(t => {
      if (t.id === activeTab) {
        const newIndex = t.historyIndex + 1
        return {
          ...t,
          url: t.history[newIndex],
          historyIndex: newIndex,
          canGoBack: true,
          canGoForward: newIndex < t.history.length - 1,
          loading: true
        }
      }
      return t
    }))
  }

  const refresh = () => {
    if (iframeRef.current && currentTab?.url) {
      setTabs(tabs.map(t => t.id === activeTab ? { ...t, loading: true } : t))
      iframeRef.current.src = currentTab.url
    }
  }

  const goHome = () => {
    setTabs(tabs.map(t => {
      if (t.id === activeTab) {
        return { ...t, url: '', title: 'New Tab', loading: false }
      }
      return t
    }))
    setUrlInput('')
  }

  const handleIframeLoad = () => {
    setTabs(tabs.map(t => {
      if (t.id === activeTab) {
        let title = 'Web Page'
        try {
          const url = new URL(t.url)
          title = url.hostname.replace('www.', '')
        } catch {
          // ignore
        }
        return { ...t, loading: false, title }
      }
      return t
    }))
  }

  const addBookmark = () => {
    if (!currentTab?.url) return
    const exists = bookmarks.some(b => b.url === currentTab.url)
    if (!exists) {
      setBookmarks([...bookmarks, {
        id: Date.now().toString(),
        title: currentTab.title,
        url: currentTab.url,
      }])
    }
  }

  const removeBookmark = (id: string) => {
    setBookmarks(bookmarks.filter(b => b.id !== id))
  }

  const toggleExtension = (id: string) => {
    setExtensions(extensions.map(e => 
      e.id === id ? { ...e, enabled: !e.enabled } : e
    ))
  }

  const isBookmarked = currentTab ? bookmarks.some(b => b.url === currentTab.url) : false

  const clearHistory = () => {
    setHistoryItems([])
  }

  const copyUrl = () => {
    if (currentTab?.url) {
      navigator.clipboard.writeText(currentTab.url)
    }
  }

  return (
    <div className="flex flex-col h-full bg-[#1a1625] text-white">
      {/* Tab Bar */}
      <div className="flex items-center bg-[#0d0a12] px-2 pt-2 gap-1 overflow-x-auto">
        {tabs.map(tab => (
          <div
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`group flex items-center gap-2 px-3 py-2 rounded-t-lg min-w-[140px] max-w-[200px] cursor-pointer transition-all ${
              activeTab === tab.id 
                ? 'bg-[#1a1625]' 
                : 'bg-[#12101a] hover:bg-[#1a1625]/50'
            }`}
          >
            {tab.loading ? (
              <RotateCw className="w-4 h-4 animate-spin text-purple-400 shrink-0" />
            ) : (
              <Globe className="w-4 h-4 text-purple-400 shrink-0" />
            )}
            <span className="truncate text-sm flex-1">{tab.title}</span>
            {tab.muted && <VolumeX className="w-3 h-3 text-gray-500" />}
            <button
              onClick={(e) => closeTab(tab.id, e)}
              className="opacity-0 group-hover:opacity-100 hover:bg-white/10 rounded p-0.5 transition-opacity"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}
        <button
          onClick={createNewTab}
          className="p-2 hover:bg-white/10 rounded-lg transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Navigation Bar */}
      <div className="flex items-center gap-2 p-2 bg-[#1a1625] border-b border-purple-500/20">
        <button 
          onClick={goBack}
          disabled={!currentTab?.canGoBack}
          className="p-2 hover:bg-white/10 rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <button 
          onClick={goForward}
          disabled={!currentTab?.canGoForward}
          className="p-2 hover:bg-white/10 rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <ArrowRight className="w-4 h-4" />
        </button>
        <button onClick={refresh} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
          <RotateCw className={`w-4 h-4 ${currentTab?.loading ? 'animate-spin' : ''}`} />
        </button>
        <button onClick={goHome} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
          <Home className="w-4 h-4" />
        </button>

        {/* URL Bar */}
        <div className="flex-1 flex items-center bg-[#0d0a12] rounded-full px-4 py-2 gap-2 border border-purple-500/30 focus-within:border-purple-500">
          {currentTab?.url ? (
            isSecure ? (
              <Lock className="w-4 h-4 text-green-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-yellow-400 shrink-0" />
            )
          ) : (
            <Search className="w-4 h-4 text-gray-400 shrink-0" />
          )}
          <input
            type="text"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && navigate(urlInput)}
            placeholder="Search or enter URL"
            className="flex-1 bg-transparent outline-none text-sm"
          />
          {currentTab?.url && (
            <button onClick={copyUrl} className="p-1 hover:bg-white/10 rounded transition-colors" title="Copy URL">
              <Copy className="w-3 h-3 text-gray-400" />
            </button>
          )}
          <button
            onClick={addBookmark}
            className={`p-1 hover:bg-white/10 rounded transition-colors ${isBookmarked ? 'text-yellow-400' : ''}`}
          >
            <Star className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
          </button>
        </div>

        {/* Toolbar Buttons */}
        <div className="flex items-center gap-1">
          <button 
            onClick={() => { closeAllPanels(); setShowBookmarks(!showBookmarks); }}
            className={`p-2 hover:bg-white/10 rounded-lg transition-colors ${showBookmarks ? 'bg-purple-500/30' : ''}`}
            title="Bookmarks"
          >
            <Bookmark className="w-4 h-4" />
          </button>
          <button 
            onClick={() => { closeAllPanels(); setShowHistory(!showHistory); }}
            className={`p-2 hover:bg-white/10 rounded-lg transition-colors ${showHistory ? 'bg-purple-500/30' : ''}`}
            title="History"
          >
            <History className="w-4 h-4" />
          </button>
          <button 
            onClick={() => { closeAllPanels(); setShowDownloads(!showDownloads); }}
            className={`p-2 hover:bg-white/10 rounded-lg transition-colors ${showDownloads ? 'bg-purple-500/30' : ''}`}
            title="Downloads"
          >
            <Download className="w-4 h-4" />
          </button>
          <button 
            onClick={() => { closeAllPanels(); setShowExtensions(!showExtensions); }}
            className={`p-2 hover:bg-white/10 rounded-lg transition-colors ${showExtensions ? 'bg-purple-500/30' : ''}`}
            title="Extensions"
          >
            <Puzzle className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Side Panels */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Bookmarks Panel */}
        {showBookmarks && (
          <div className="absolute right-0 top-0 w-72 h-full bg-[#12101a] border-l border-purple-500/20 z-10 overflow-y-auto">
            <div className="p-4 border-b border-purple-500/20 flex items-center justify-between">
              <h3 className="font-semibold flex items-center gap-2">
                <Bookmark className="w-4 h-4" /> Bookmarks
              </h3>
              <button onClick={() => setShowBookmarks(false)} className="p-1 hover:bg-white/10 rounded">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-2">
              {bookmarks.length === 0 ? (
                <p className="text-gray-500 text-sm text-center py-4">No bookmarks yet</p>
              ) : (
                bookmarks.map(bookmark => (
                  <div key={bookmark.id} className="flex items-center gap-2 p-2 hover:bg-white/5 rounded-lg group">
                    <Globe className="w-4 h-4 text-purple-400 shrink-0" />
                    <button
                      onClick={() => navigate(bookmark.url)}
                      className="flex-1 text-left text-sm truncate hover:text-purple-300"
                    >
                      {bookmark.title}
                    </button>
                    <button
                      onClick={() => removeBookmark(bookmark.id)}
                      className="opacity-0 group-hover:opacity-100 p-1 hover:bg-white/10 rounded"
                    >
                      <Trash2 className="w-3 h-3 text-red-400" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* History Panel */}
        {showHistory && (
          <div className="absolute right-0 top-0 w-72 h-full bg-[#12101a] border-l border-purple-500/20 z-10 overflow-y-auto">
            <div className="p-4 border-b border-purple-500/20 flex items-center justify-between">
              <h3 className="font-semibold flex items-center gap-2">
                <History className="w-4 h-4" /> History
              </h3>
              <div className="flex gap-2">
                <button onClick={clearHistory} className="text-xs text-red-400 hover:text-red-300">
                  Clear All
                </button>
                <button onClick={() => setShowHistory(false)} className="p-1 hover:bg-white/10 rounded">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="p-2">
              {historyItems.length === 0 ? (
                <p className="text-gray-500 text-sm text-center py-4">No history yet</p>
              ) : (
                historyItems.map(item => (
                  <button
                    key={item.id}
                    onClick={() => navigate(item.url)}
                    className="flex items-center gap-2 p-2 hover:bg-white/5 rounded-lg w-full text-left"
                  >
                    <Clock className="w-4 h-4 text-gray-500 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm truncate">{item.title}</p>
                      <p className="text-xs text-gray-500">{item.visitedAt.toLocaleTimeString()}</p>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        )}

        {/* Downloads Panel */}
        {showDownloads && (
          <div className="absolute right-0 top-0 w-72 h-full bg-[#12101a] border-l border-purple-500/20 z-10 overflow-y-auto">
            <div className="p-4 border-b border-purple-500/20 flex items-center justify-between">
              <h3 className="font-semibold flex items-center gap-2">
                <Download className="w-4 h-4" /> Downloads
              </h3>
              <button onClick={() => setShowDownloads(false)} className="p-1 hover:bg-white/10 rounded">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-2">
              {downloads.length === 0 ? (
                <p className="text-gray-500 text-sm text-center py-4">No downloads</p>
              ) : (
                downloads.map((dl, i) => (
                  <div key={i} className="p-2 hover:bg-white/5 rounded-lg">
                    <p className="text-sm truncate">{dl.name}</p>
                    <div className="w-full h-1 bg-gray-700 rounded mt-1">
                      <div 
                        className="h-full bg-purple-500 rounded transition-all"
                        style={{ width: `${dl.progress}%` }}
                      />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Extensions Panel */}
        {showExtensions && (
          <div className="absolute right-0 top-0 w-72 h-full bg-[#12101a] border-l border-purple-500/20 z-10 overflow-y-auto">
            <div className="p-4 border-b border-purple-500/20 flex items-center justify-between">
              <h3 className="font-semibold flex items-center gap-2">
                <Puzzle className="w-4 h-4" /> Extensions
              </h3>
              <button onClick={() => setShowExtensions(false)} className="p-1 hover:bg-white/10 rounded">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-2 space-y-2">
              {extensions.map(ext => (
                <div key={ext.id} className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                  <div className={`p-2 rounded-lg ${ext.enabled ? 'bg-purple-500/30 text-purple-300' : 'bg-gray-700 text-gray-400'}`}>
                    {ext.icon}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{ext.name}</p>
                    <p className="text-xs text-gray-500">{ext.description}</p>
                  </div>
                  <button
                    onClick={() => toggleExtension(ext.id)}
                    className={`w-10 h-5 rounded-full transition-colors ${ext.enabled ? 'bg-purple-500' : 'bg-gray-600'}`}
                  >
                    <div className={`w-4 h-4 rounded-full bg-white transition-transform ${ext.enabled ? 'translate-x-5' : 'translate-x-0.5'}`} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Browser Content */}
        <div className="flex-1 bg-[#0d0a12]">
          {!currentTab?.url ? (
            /* New Tab Page */
            <div className="h-full flex flex-col items-center justify-center p-8">
              <div className="text-center mb-8">
                <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-violet-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/30">
                  <Globe className="w-10 h-10 text-white" />
                </div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-violet-300 bg-clip-text text-transparent">
                  Rebirth Browser
                </h1>
                <p className="text-gray-500 text-sm mt-1">by v/admin</p>
              </div>

              {/* Search Bar */}
              <div className="w-full max-w-xl mb-8">
                <div className="flex items-center bg-[#1a1625] rounded-full px-6 py-4 gap-3 border border-purple-500/30 focus-within:border-purple-500 shadow-lg">
                  <Search className="w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && navigate(urlInput)}
                    placeholder="Search the web or enter URL..."
                    className="flex-1 bg-transparent outline-none text-lg"
                    autoFocus
                  />
                </div>
              </div>

              {/* Quick Links */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-4 max-w-2xl">
                {quickLinks.map((link, i) => (
                  <button
                    key={i}
                    onClick={() => navigate(link.url)}
                    className="flex flex-col items-center gap-2 p-4 rounded-xl hover:bg-white/5 transition-colors group"
                  >
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-500/20 to-violet-500/20 rounded-xl flex items-center justify-center group-hover:from-purple-500/30 group-hover:to-violet-500/30 transition-colors">
                      <Globe className="w-6 h-6 text-purple-400" />
                    </div>
                    <span className="text-xs text-gray-400 group-hover:text-white transition-colors">{link.name}</span>
                  </button>
                ))}
              </div>

              {/* Active Extensions */}
              <div className="mt-8 flex items-center gap-2 text-xs text-gray-500">
                <Shield className="w-4 h-4 text-green-400" />
                {extensions.filter(e => e.enabled).length} extensions active
              </div>
            </div>
          ) : (
            /* Web Page - Real iframe */
            <iframe
              ref={iframeRef}
              src={currentTab.url}
              className="w-full h-full border-0"
              onLoad={handleIframeLoad}
              sandbox="allow-same-origin allow-scripts allow-popups allow-forms allow-presentation"
              referrerPolicy="no-referrer"
              title={currentTab.title}
            />
          )}
        </div>
      </div>
    </div>
  )
}

export default Browser
