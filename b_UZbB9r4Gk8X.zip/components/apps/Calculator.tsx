'use client'

import { useState } from 'react'
import { Delete } from 'lucide-react'

export function Calculator() {
  const [display, setDisplay] = useState('0')
  const [previousValue, setPreviousValue] = useState<number | null>(null)
  const [operator, setOperator] = useState<string | null>(null)
  const [waitingForOperand, setWaitingForOperand] = useState(false)

  const inputDigit = (digit: string) => {
    if (waitingForOperand) {
      setDisplay(digit)
      setWaitingForOperand(false)
    } else {
      setDisplay(display === '0' ? digit : display + digit)
    }
  }

  const inputDecimal = () => {
    if (waitingForOperand) {
      setDisplay('0.')
      setWaitingForOperand(false)
      return
    }
    if (!display.includes('.')) {
      setDisplay(display + '.')
    }
  }

  const clear = () => {
    setDisplay('0')
    setPreviousValue(null)
    setOperator(null)
    setWaitingForOperand(false)
  }

  const clearEntry = () => {
    setDisplay('0')
  }

  const toggleSign = () => {
    setDisplay(String(-parseFloat(display)))
  }

  const inputPercent = () => {
    setDisplay(String(parseFloat(display) / 100))
  }

  const performOperation = (nextOperator: string) => {
    const inputValue = parseFloat(display)

    if (previousValue === null) {
      setPreviousValue(inputValue)
    } else if (operator) {
      const result = calculate(previousValue, inputValue, operator)
      setDisplay(String(result))
      setPreviousValue(result)
    }

    setWaitingForOperand(true)
    setOperator(nextOperator)
  }

  const calculate = (left: number, right: number, op: string): number => {
    switch (op) {
      case '+':
        return left + right
      case '-':
        return left - right
      case '×':
        return left * right
      case '÷':
        return right !== 0 ? left / right : 0
      default:
        return right
    }
  }

  const equals = () => {
    if (operator && previousValue !== null) {
      const inputValue = parseFloat(display)
      const result = calculate(previousValue, inputValue, operator)
      setDisplay(String(result))
      setPreviousValue(null)
      setOperator(null)
      setWaitingForOperand(true)
    }
  }

  const Button = ({
    onClick,
    children,
    className = '',
    span = 1,
  }: {
    onClick: () => void
    children: React.ReactNode
    className?: string
    span?: number
  }) => (
    <button
      onClick={onClick}
      className={`flex items-center justify-center rounded-lg text-lg font-medium transition-all active:scale-95 ${className}`}
      style={{ gridColumn: span > 1 ? `span ${span}` : undefined }}
    >
      {children}
    </button>
  )

  return (
    <div className="flex flex-col h-full bg-[#1a1a1a] p-3">
      {/* Display */}
      <div className="flex-1 flex flex-col justify-end p-4 min-h-32">
        <div className="text-right">
          {previousValue !== null && operator && (
            <div className="text-sm text-muted-foreground mb-1">
              {previousValue} {operator}
            </div>
          )}
          <div className="text-4xl font-light text-white truncate">
            {display}
          </div>
        </div>
      </div>

      {/* Buttons */}
      <div className="grid grid-cols-4 gap-2">
        <Button onClick={inputPercent} className="bg-[#323232] text-white h-14 hover:bg-[#3d3d3d]">
          %
        </Button>
        <Button onClick={clearEntry} className="bg-[#323232] text-white h-14 hover:bg-[#3d3d3d]">
          CE
        </Button>
        <Button onClick={clear} className="bg-[#323232] text-white h-14 hover:bg-[#3d3d3d]">
          C
        </Button>
        <Button onClick={() => setDisplay(display.slice(0, -1) || '0')} className="bg-[#323232] text-white h-14 hover:bg-[#3d3d3d]">
          <Delete className="h-5 w-5" />
        </Button>

        <Button onClick={() => setDisplay(String(1 / parseFloat(display)))} className="bg-[#323232] text-white h-14 hover:bg-[#3d3d3d]">
          1/x
        </Button>
        <Button onClick={() => setDisplay(String(Math.pow(parseFloat(display), 2)))} className="bg-[#323232] text-white h-14 hover:bg-[#3d3d3d]">
          x²
        </Button>
        <Button onClick={() => setDisplay(String(Math.sqrt(parseFloat(display))))} className="bg-[#323232] text-white h-14 hover:bg-[#3d3d3d]">
          √x
        </Button>
        <Button onClick={() => performOperation('÷')} className="bg-[#323232] text-white h-14 hover:bg-[#3d3d3d]">
          ÷
        </Button>

        <Button onClick={() => inputDigit('7')} className="bg-[#3b3b3b] text-white h-14 hover:bg-[#4a4a4a]">
          7
        </Button>
        <Button onClick={() => inputDigit('8')} className="bg-[#3b3b3b] text-white h-14 hover:bg-[#4a4a4a]">
          8
        </Button>
        <Button onClick={() => inputDigit('9')} className="bg-[#3b3b3b] text-white h-14 hover:bg-[#4a4a4a]">
          9
        </Button>
        <Button onClick={() => performOperation('×')} className="bg-[#323232] text-white h-14 hover:bg-[#3d3d3d]">
          ×
        </Button>

        <Button onClick={() => inputDigit('4')} className="bg-[#3b3b3b] text-white h-14 hover:bg-[#4a4a4a]">
          4
        </Button>
        <Button onClick={() => inputDigit('5')} className="bg-[#3b3b3b] text-white h-14 hover:bg-[#4a4a4a]">
          5
        </Button>
        <Button onClick={() => inputDigit('6')} className="bg-[#3b3b3b] text-white h-14 hover:bg-[#4a4a4a]">
          6
        </Button>
        <Button onClick={() => performOperation('-')} className="bg-[#323232] text-white h-14 hover:bg-[#3d3d3d]">
          −
        </Button>

        <Button onClick={() => inputDigit('1')} className="bg-[#3b3b3b] text-white h-14 hover:bg-[#4a4a4a]">
          1
        </Button>
        <Button onClick={() => inputDigit('2')} className="bg-[#3b3b3b] text-white h-14 hover:bg-[#4a4a4a]">
          2
        </Button>
        <Button onClick={() => inputDigit('3')} className="bg-[#3b3b3b] text-white h-14 hover:bg-[#4a4a4a]">
          3
        </Button>
        <Button onClick={() => performOperation('+')} className="bg-[#323232] text-white h-14 hover:bg-[#3d3d3d]">
          +
        </Button>

        <Button onClick={toggleSign} className="bg-[#3b3b3b] text-white h-14 hover:bg-[#4a4a4a]">
          +/−
        </Button>
        <Button onClick={() => inputDigit('0')} className="bg-[#3b3b3b] text-white h-14 hover:bg-[#4a4a4a]">
          0
        </Button>
        <Button onClick={inputDecimal} className="bg-[#3b3b3b] text-white h-14 hover:bg-[#4a4a4a]">
          .
        </Button>
        <Button onClick={equals} className="bg-primary text-primary-foreground h-14 hover:bg-primary/90">
          =
        </Button>
      </div>
    </div>
  )
}
