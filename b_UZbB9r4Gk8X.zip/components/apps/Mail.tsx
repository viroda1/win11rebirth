"use client"

import { useState } from 'react'
import { 
  Mail, Inbox, Send, Star, Trash2, Archive, Search,
  Plus, RefreshCw, ChevronLeft, Paperclip, MoreVertical,
  Reply, Forward, Clock, User
} from 'lucide-react'

interface Email {
  id: string
  from: string
  fromEmail: string
  subject: string
  preview: string
  body: string
  date: Date
  read: boolean
  starred: boolean
  folder: 'inbox' | 'sent' | 'starred' | 'trash' | 'archive'
  hasAttachment: boolean
}

const mockEmails: Email[] = [
  {
    id: '1',
    from: 'ViroNexus Team',
    fromEmail: 'team@vironexus.rf.gd',
    subject: 'Welcome to Win11 Rebirth!',
    preview: 'Thank you for choosing Win11 Rebirth. We are excited to have you...',
    body: `Dear User,

Thank you for choosing Win11 Rebirth! We are excited to have you as part of our community.

Win11 Rebirth brings you a modern, beautiful operating system experience right in your browser. Explore our apps, customize your desktop, and make it truly yours.

Features include:
- Beautiful purple-themed interface
- Working browser with tabs
- File Explorer
- Games, Music, and more!

If you have any questions, feel free to reach out.

Best regards,
The ViroNexus Team`,
    date: new Date(),
    read: false,
    starred: true,
    folder: 'inbox',
    hasAttachment: false,
  },
  {
    id: '2',
    from: 'v/admin',
    fromEmail: 'admin@vironexus.rf.gd',
    subject: 'System Update Available',
    preview: 'A new system update is available for Win11 Rebirth...',
    body: `Hello,

A new system update is available for Win11 Rebirth. This update includes:

- Performance improvements
- New wallpapers
- Bug fixes
- Enhanced browser functionality

The update will be applied automatically.

Cheers,
v/admin`,
    date: new Date(Date.now() - 86400000),
    read: true,
    starred: false,
    folder: 'inbox',
    hasAttachment: true,
  },
  {
    id: '3',
    from: 'Rebirth Store',
    fromEmail: 'store@rebirth.app',
    subject: 'New apps available in the Store',
    preview: 'Check out the latest apps available in the Rebirth Store...',
    body: `Hey there!

We've added some exciting new apps to the Rebirth Store:

1. ViroCode - A powerful code editor
2. Beat Studio - Music production suite
3. Cyber Runner - Fast-paced game

Download them now and enhance your Rebirth experience!

- The Rebirth Store Team`,
    date: new Date(Date.now() - 172800000),
    read: true,
    starred: false,
    folder: 'inbox',
    hasAttachment: false,
  },
]

const folders = [
  { id: 'inbox', name: 'Inbox', icon: <Inbox className="w-4 h-4" /> },
  { id: 'starred', name: 'Starred', icon: <Star className="w-4 h-4" /> },
  { id: 'sent', name: 'Sent', icon: <Send className="w-4 h-4" /> },
  { id: 'archive', name: 'Archive', icon: <Archive className="w-4 h-4" /> },
  { id: 'trash', name: 'Trash', icon: <Trash2 className="w-4 h-4" /> },
]

export default function MailApp() {
  const [emails, setEmails] = useState<Email[]>(mockEmails)
  const [selectedFolder, setSelectedFolder] = useState('inbox')
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [showCompose, setShowCompose] = useState(false)
  const [composeData, setComposeData] = useState({ to: '', subject: '', body: '' })

  const filteredEmails = emails.filter(e => {
    if (selectedFolder === 'starred') return e.starred
    return e.folder === selectedFolder
  }).filter(e => 
    e.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.from.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const unreadCount = emails.filter(e => !e.read && e.folder === 'inbox').length

  const openEmail = (email: Email) => {
    setSelectedEmail(email)
    if (!email.read) {
      setEmails(emails.map(e => e.id === email.id ? { ...e, read: true } : e))
    }
  }

  const toggleStar = (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    setEmails(emails.map(em => em.id === id ? { ...em, starred: !em.starred } : em))
  }

  const deleteEmail = (id: string) => {
    setEmails(emails.map(e => e.id === id ? { ...e, folder: 'trash' } : e))
    setSelectedEmail(null)
  }

  const archiveEmail = (id: string) => {
    setEmails(emails.map(e => e.id === id ? { ...e, folder: 'archive' } : e))
    setSelectedEmail(null)
  }

  const sendEmail = () => {
    if (!composeData.to || !composeData.subject) return
    
    const newEmail: Email = {
      id: Date.now().toString(),
      from: 'Me',
      fromEmail: 'user@rebirth.app',
      subject: composeData.subject,
      preview: composeData.body.slice(0, 100),
      body: composeData.body,
      date: new Date(),
      read: true,
      starred: false,
      folder: 'sent',
      hasAttachment: false,
    }
    
    setEmails([newEmail, ...emails])
    setShowCompose(false)
    setComposeData({ to: '', subject: '', body: '' })
  }

  const formatDate = (date: Date) => {
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const days = Math.floor(diff / 86400000)
    
    if (days === 0) return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    if (days === 1) return 'Yesterday'
    if (days < 7) return date.toLocaleDateString([], { weekday: 'short' })
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' })
  }

  return (
    <div className="flex h-full bg-[#0d0a12] text-white">
      {/* Sidebar */}
      <div className="w-56 bg-[#12101a] border-r border-purple-500/20 flex flex-col">
        <div className="p-4">
          <button
            onClick={() => setShowCompose(true)}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-purple-500 hover:bg-purple-600 rounded-xl font-medium transition-colors"
          >
            <Plus className="w-4 h-4" />
            Compose
          </button>
        </div>

        <nav className="flex-1 p-2">
          {folders.map(folder => (
            <button
              key={folder.id}
              onClick={() => { setSelectedFolder(folder.id); setSelectedEmail(null); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                selectedFolder === folder.id
                  ? 'bg-purple-500/30 text-purple-300'
                  : 'hover:bg-white/5 text-gray-400'
              }`}
            >
              {folder.icon}
              <span className="flex-1 text-left text-sm">{folder.name}</span>
              {folder.id === 'inbox' && unreadCount > 0 && (
                <span className="bg-purple-500 text-xs px-2 py-0.5 rounded-full">{unreadCount}</span>
              )}
            </button>
          ))}
        </nav>
      </div>

      {/* Email List */}
      <div className={`${selectedEmail ? 'hidden md:flex' : 'flex'} flex-col w-80 bg-[#12101a]/50 border-r border-purple-500/20`}>
        <div className="p-3 border-b border-purple-500/20">
          <div className="flex items-center bg-black/30 rounded-lg px-3 py-2 gap-2 border border-purple-500/30">
            <Search className="w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search mail..."
              className="flex-1 bg-transparent outline-none text-sm"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {filteredEmails.length === 0 ? (
            <div className="text-center text-gray-500 py-8">
              <Mail className="w-12 h-12 mx-auto mb-2 opacity-30" />
              <p className="text-sm">No emails</p>
            </div>
          ) : (
            filteredEmails.map(email => (
              <button
                key={email.id}
                onClick={() => openEmail(email)}
                className={`w-full text-left p-3 border-b border-purple-500/10 hover:bg-white/5 transition-colors ${
                  !email.read ? 'bg-purple-500/10' : ''
                } ${selectedEmail?.id === email.id ? 'bg-purple-500/20' : ''}`}
              >
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-violet-600 rounded-full flex items-center justify-center text-xs font-bold shrink-0">
                    {email.from[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className={`text-sm truncate ${!email.read ? 'font-semibold' : ''}`}>
                        {email.from}
                      </span>
                      <span className="text-xs text-gray-500 shrink-0">{formatDate(email.date)}</span>
                    </div>
                    <p className={`text-sm truncate ${!email.read ? 'font-medium' : 'text-gray-400'}`}>
                      {email.subject}
                    </p>
                    <p className="text-xs text-gray-500 truncate">{email.preview}</p>
                  </div>
                  <button
                    onClick={(e) => toggleStar(email.id, e)}
                    className={`shrink-0 ${email.starred ? 'text-yellow-400' : 'text-gray-600 hover:text-gray-400'}`}
                  >
                    <Star className={`w-4 h-4 ${email.starred ? 'fill-current' : ''}`} />
                  </button>
                </div>
                {email.hasAttachment && (
                  <div className="flex items-center gap-1 mt-1 text-xs text-gray-500">
                    <Paperclip className="w-3 h-3" />
                    <span>Attachment</span>
                  </div>
                )}
              </button>
            ))
          )}
        </div>
      </div>

      {/* Email View */}
      <div className="flex-1 flex flex-col">
        {selectedEmail ? (
          <>
            <div className="flex items-center gap-2 p-3 border-b border-purple-500/20">
              <button
                onClick={() => setSelectedEmail(null)}
                className="p-2 hover:bg-white/10 rounded-lg md:hidden"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <div className="flex-1" />
              <button
                onClick={() => archiveEmail(selectedEmail.id)}
                className="p-2 hover:bg-white/10 rounded-lg"
                title="Archive"
              >
                <Archive className="w-4 h-4" />
              </button>
              <button
                onClick={() => deleteEmail(selectedEmail.id)}
                className="p-2 hover:bg-white/10 rounded-lg text-red-400"
                title="Delete"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <button className="p-2 hover:bg-white/10 rounded-lg">
                <MoreVertical className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              <h1 className="text-xl font-bold mb-4">{selectedEmail.subject}</h1>
              
              <div className="flex items-start gap-4 mb-6">
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-violet-600 rounded-full flex items-center justify-center text-lg font-bold">
                  {selectedEmail.from[0]}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{selectedEmail.from}</span>
                    <span className="text-sm text-gray-500">&lt;{selectedEmail.fromEmail}&gt;</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <Clock className="w-3 h-3" />
                    <span>{selectedEmail.date.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              <div className="prose prose-invert max-w-none">
                <pre className="whitespace-pre-wrap font-sans text-gray-300 leading-relaxed">
                  {selectedEmail.body}
                </pre>
              </div>
            </div>

            <div className="flex items-center gap-2 p-3 border-t border-purple-500/20">
              <button className="flex items-center gap-2 px-4 py-2 bg-purple-500/30 hover:bg-purple-500/50 rounded-lg transition-colors">
                <Reply className="w-4 h-4" />
                Reply
              </button>
              <button className="flex items-center gap-2 px-4 py-2 hover:bg-white/10 rounded-lg transition-colors">
                <Forward className="w-4 h-4" />
                Forward
              </button>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-gray-500">
            <Mail className="w-16 h-16 mb-4 opacity-30" />
            <p>Select an email to read</p>
          </div>
        )}
      </div>

      {/* Compose Modal */}
      {showCompose && (
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-[#1a1625] rounded-2xl w-full max-w-lg border border-purple-500/30 flex flex-col max-h-[80vh]">
            <div className="flex items-center justify-between p-4 border-b border-purple-500/20">
              <h3 className="font-semibold">New Message</h3>
              <button onClick={() => setShowCompose(false)} className="p-1 hover:bg-white/10 rounded">
                <Mail className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              <input
                type="email"
                value={composeData.to}
                onChange={(e) => setComposeData({ ...composeData, to: e.target.value })}
                placeholder="To"
                className="w-full bg-black/30 rounded-lg px-4 py-2 outline-none border border-purple-500/30 focus:border-purple-500"
              />
              <input
                type="text"
                value={composeData.subject}
                onChange={(e) => setComposeData({ ...composeData, subject: e.target.value })}
                placeholder="Subject"
                className="w-full bg-black/30 rounded-lg px-4 py-2 outline-none border border-purple-500/30 focus:border-purple-500"
              />
              <textarea
                value={composeData.body}
                onChange={(e) => setComposeData({ ...composeData, body: e.target.value })}
                placeholder="Write your message..."
                rows={10}
                className="w-full bg-black/30 rounded-lg px-4 py-2 outline-none border border-purple-500/30 focus:border-purple-500 resize-none"
              />
            </div>
            <div className="flex items-center justify-between p-4 border-t border-purple-500/20">
              <button className="p-2 hover:bg-white/10 rounded-lg">
                <Paperclip className="w-4 h-4" />
              </button>
              <button
                onClick={sendEmail}
                className="flex items-center gap-2 px-6 py-2 bg-purple-500 hover:bg-purple-600 rounded-lg font-medium transition-colors"
              >
                <Send className="w-4 h-4" />
                Send
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
