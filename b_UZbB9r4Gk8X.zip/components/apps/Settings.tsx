'use client'

import { useState } from 'react'
import { useOSStore } from '@/lib/store'
import {
  User,
  Palette,
  Monitor,
  Bell,
  Wifi,
  Shield,
  Clock,
  Info,
  ChevronRight,
  Moon,
  Sun,
  Volume2,
  Check,
} from 'lucide-react'

type SettingsPage = 'system' | 'personalization' | 'accounts' | 'network' | 'privacy' | 'time' | 'about'

const wallpapers = [
  { id: 0, name: 'Purple Nebula', color: 'from-[#1a0a2e] via-[#16082a] to-[#0d0515]' },
  { id: 1, name: 'Cosmic Blue', color: 'from-[#0f0c29] via-[#302b63] to-[#24243e]' },
  { id: 2, name: 'Deep Violet', color: 'from-[#1e1e2e] via-[#3e1f47] to-[#1a1a2e]' },
  { id: 3, name: 'Dark Matter', color: 'from-[#0a0a0f] via-[#1a0a2e] to-[#2d1b4e]' },
  { id: 4, name: 'Midnight', color: 'from-[#1a1c2e] via-[#2d1f54] to-[#0d0515]' },
]

const avatars = ['👤', '😎', '🦊', '🐱', '🐸', '🦄', '🤖', '👾', '🎮', '💜', '⭐', '🔮']

export function Settings() {
  const { user, setWallpaper, setAvatar, volume, setVolume, wifi, toggleWifi, bluetooth, toggleBluetooth } = useOSStore()
  const [currentPage, setCurrentPage] = useState<SettingsPage>('personalization')

  const menuItems = [
    { id: 'system' as const, icon: Monitor, label: 'System' },
    { id: 'personalization' as const, icon: Palette, label: 'Personalization' },
    { id: 'accounts' as const, icon: User, label: 'Accounts' },
    { id: 'network' as const, icon: Wifi, label: 'Network & Internet' },
    { id: 'privacy' as const, icon: Shield, label: 'Privacy & Security' },
    { id: 'time' as const, icon: Clock, label: 'Time & Language' },
    { id: 'about' as const, icon: Info, label: 'About' },
  ]

  const renderContent = () => {
    switch (currentPage) {
      case 'personalization':
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-2">Personalization</h2>
              <p className="text-muted-foreground">Customize your Win11 Rebirth experience</p>
            </div>

            {/* Avatar selection */}
            <div className="space-y-3">
              <h3 className="text-lg font-medium text-foreground">Avatar</h3>
              <div className="grid grid-cols-6 gap-3">
                {avatars.map((avatar) => (
                  <button
                    key={avatar}
                    onClick={() => setAvatar(avatar)}
                    className={`flex h-14 w-14 items-center justify-center rounded-xl text-2xl transition-all ${
                      user?.avatar === avatar
                        ? 'bg-primary ring-2 ring-primary ring-offset-2 ring-offset-background'
                        : 'bg-secondary hover:bg-secondary/80'
                    }`}
                  >
                    {avatar}
                  </button>
                ))}
              </div>
            </div>

            {/* Wallpaper selection */}
            <div className="space-y-3">
              <h3 className="text-lg font-medium text-foreground">Background</h3>
              <div className="grid grid-cols-5 gap-3">
                {wallpapers.map((wp) => (
                  <button
                    key={wp.id}
                    onClick={() => setWallpaper(wp.id)}
                    className={`relative h-24 rounded-xl overflow-hidden transition-all ${
                      user?.wallpaper === wp.id
                        ? 'ring-2 ring-primary ring-offset-2 ring-offset-background'
                        : 'hover:ring-1 hover:ring-muted-foreground'
                    }`}
                  >
                    <div className={`absolute inset-0 bg-gradient-to-br ${wp.color}`} />
                    {user?.wallpaper === wp.id && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                        <Check className="h-6 w-6 text-white" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
              <p className="text-sm text-muted-foreground">
                Selected: {wallpapers.find(w => w.id === user?.wallpaper)?.name || 'Purple Nebula'}
              </p>
            </div>

            {/* Accent color info */}
            <div className="space-y-3">
              <h3 className="text-lg font-medium text-foreground">Accent Color</h3>
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-xl bg-primary" />
                <div>
                  <p className="text-foreground font-medium">Purple</p>
                  <p className="text-sm text-muted-foreground">Win11 Rebirth signature color</p>
                </div>
              </div>
            </div>
          </div>
        )

      case 'system':
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-2">System</h2>
              <p className="text-muted-foreground">Display, sound, and notifications</p>
            </div>

            {/* Display */}
            <div className="space-y-3">
              <h3 className="text-lg font-medium text-foreground">Display</h3>
              <div className="rounded-xl bg-secondary p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Sun className="h-5 w-5 text-muted-foreground" />
                    <span className="text-foreground">Night Light</span>
                  </div>
                  <button className="h-6 w-11 rounded-full bg-muted relative">
                    <div className="h-5 w-5 rounded-full bg-muted-foreground absolute left-0.5 top-0.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Sound */}
            <div className="space-y-3">
              <h3 className="text-lg font-medium text-foreground">Sound</h3>
              <div className="rounded-xl bg-secondary p-4 space-y-4">
                <div className="flex items-center gap-4">
                  <Volume2 className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={volume}
                    onChange={(e) => setVolume(parseInt(e.target.value))}
                    className="flex-1 h-2 bg-muted rounded-full appearance-none cursor-pointer accent-primary"
                  />
                  <span className="text-sm text-muted-foreground w-8">{volume}%</span>
                </div>
              </div>
            </div>

            {/* Notifications */}
            <div className="space-y-3">
              <h3 className="text-lg font-medium text-foreground">Notifications</h3>
              <div className="rounded-xl bg-secondary p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Bell className="h-5 w-5 text-muted-foreground" />
                    <span className="text-foreground">Enable notifications</span>
                  </div>
                  <button className="h-6 w-11 rounded-full bg-primary relative">
                    <div className="h-5 w-5 rounded-full bg-white absolute right-0.5 top-0.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )

      case 'accounts':
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-2">Accounts</h2>
              <p className="text-muted-foreground">Your account and profile</p>
            </div>

            <div className="rounded-xl bg-secondary p-6">
              <div className="flex items-center gap-4">
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/20 text-4xl">
                  {user?.avatar || '👤'}
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-foreground">
                    {user?.username || 'User'}
                  </h3>
                  <p className="text-muted-foreground">Local Account</p>
                  <p className="text-sm text-primary mt-1">Administrator</p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <button className="flex items-center justify-between w-full rounded-xl bg-secondary p-4 hover:bg-secondary/80 transition-colors">
                <span className="text-foreground">Sign-in options</span>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </button>
              <button className="flex items-center justify-between w-full rounded-xl bg-secondary p-4 hover:bg-secondary/80 transition-colors">
                <span className="text-foreground">Email & accounts</span>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </button>
            </div>
          </div>
        )

      case 'network':
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-2">Network & Internet</h2>
              <p className="text-muted-foreground">Wi-Fi, Bluetooth, and connections</p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between rounded-xl bg-secondary p-4">
                <div className="flex items-center gap-3">
                  <Wifi className={`h-5 w-5 ${wifi ? 'text-primary' : 'text-muted-foreground'}`} />
                  <div>
                    <span className="text-foreground block">Wi-Fi</span>
                    <span className="text-sm text-muted-foreground">
                      {wifi ? 'Connected' : 'Disconnected'}
                    </span>
                  </div>
                </div>
                <button
                  onClick={toggleWifi}
                  className={`h-6 w-11 rounded-full relative transition-colors ${
                    wifi ? 'bg-primary' : 'bg-muted'
                  }`}
                >
                  <div
                    className={`h-5 w-5 rounded-full bg-white absolute top-0.5 transition-all ${
                      wifi ? 'right-0.5' : 'left-0.5'
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-between rounded-xl bg-secondary p-4">
                <div className="flex items-center gap-3">
                  <div className={`h-5 w-5 ${bluetooth ? 'text-primary' : 'text-muted-foreground'}`}>
                    📶
                  </div>
                  <div>
                    <span className="text-foreground block">Bluetooth</span>
                    <span className="text-sm text-muted-foreground">
                      {bluetooth ? 'On' : 'Off'}
                    </span>
                  </div>
                </div>
                <button
                  onClick={toggleBluetooth}
                  className={`h-6 w-11 rounded-full relative transition-colors ${
                    bluetooth ? 'bg-primary' : 'bg-muted'
                  }`}
                >
                  <div
                    className={`h-5 w-5 rounded-full bg-white absolute top-0.5 transition-all ${
                      bluetooth ? 'right-0.5' : 'left-0.5'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>
        )

      case 'about':
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-2">About</h2>
              <p className="text-muted-foreground">Device and system information</p>
            </div>

            <div className="rounded-xl bg-secondary p-6 space-y-4">
              <div className="flex items-center gap-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-primary/20">
                  <span className="text-3xl font-bold text-primary">W11</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-foreground">Win11 Rebirth</h3>
                  <p className="text-muted-foreground">Version 1.0.0</p>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between py-2 border-b border-border">
                <span className="text-muted-foreground">Developer</span>
                <span className="text-foreground">v/admin (viroda1)</span>
              </div>
              <div className="flex justify-between py-2 border-b border-border">
                <span className="text-muted-foreground">Website</span>
                <a href="https://vironexus.rf.gd" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                  vironexus.rf.gd
                </a>
              </div>
              <div className="flex justify-between py-2 border-b border-border">
                <span className="text-muted-foreground">GitHub</span>
                <a href="https://github.com/viroda1" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                  github.com/viroda1
                </a>
              </div>
              <div className="flex justify-between py-2 border-b border-border">
                <span className="text-muted-foreground">Built with</span>
                <span className="text-foreground">Next.js + React</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-muted-foreground">License</span>
                <span className="text-foreground">MIT</span>
              </div>
            </div>

            <div className="rounded-xl bg-primary/10 p-4 border border-primary/20">
              <p className="text-sm text-foreground">
                Win11 Rebirth is a web-based Windows 11 experience built with modern web technologies.
                Created with passion by v/admin as part of the ViroNexus project.
              </p>
            </div>
          </div>
        )

      default:
        return (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            Coming soon...
          </div>
        )
    }
  }

  return (
    <div className="flex h-full bg-background">
      {/* Sidebar */}
      <div className="w-64 border-r border-border p-4">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/20 text-2xl">
            {user?.avatar || '👤'}
          </div>
          <div>
            <span className="text-foreground font-medium block">{user?.username || 'User'}</span>
            <span className="text-sm text-muted-foreground">Local Account</span>
          </div>
        </div>

        <nav className="space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setCurrentPage(item.id)}
              className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-lg transition-colors ${
                currentPage === item.id
                  ? 'bg-primary/20 text-primary'
                  : 'hover:bg-secondary text-foreground'
              }`}
            >
              <item.icon className="h-5 w-5" />
              <span className="text-sm">{item.label}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Content */}
      <div className="flex-1 p-6 overflow-auto">{renderContent()}</div>
    </div>
  )
}
