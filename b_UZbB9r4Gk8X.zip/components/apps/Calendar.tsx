"use client"

import { useState } from 'react'
import { 
  ChevronLeft, ChevronRight, Plus, X, Clock, MapPin, 
  Calendar as CalendarIcon, Trash2, Edit2, Check
} from 'lucide-react'

interface Event {
  id: string
  title: string
  date: Date
  time: string
  location?: string
  color: string
}

const COLORS = [
  'bg-purple-500',
  'bg-blue-500',
  'bg-green-500',
  'bg-yellow-500',
  'bg-pink-500',
  'bg-red-500',
]

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
]

export default function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [events, setEvents] = useState<Event[]>([
    {
      id: '1',
      title: 'Team Meeting',
      date: new Date(),
      time: '10:00 AM',
      location: 'Conference Room A',
      color: 'bg-purple-500',
    },
    {
      id: '2',
      title: 'Project Review',
      date: new Date(Date.now() + 86400000),
      time: '2:00 PM',
      color: 'bg-blue-500',
    },
  ])
  const [showAddEvent, setShowAddEvent] = useState(false)
  const [newEvent, setNewEvent] = useState({
    title: '',
    time: '12:00',
    location: '',
    color: COLORS[0],
  })
  const [editingEvent, setEditingEvent] = useState<Event | null>(null)

  const year = currentDate.getFullYear()
  const month = currentDate.getMonth()

  const firstDayOfMonth = new Date(year, month, 1).getDay()
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  const daysInPrevMonth = new Date(year, month, 0).getDate()

  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1))
  }

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1))
  }

  const goToToday = () => {
    setCurrentDate(new Date())
    setSelectedDate(new Date())
  }

  const getDayEvents = (day: number, monthOffset = 0) => {
    const date = new Date(year, month + monthOffset, day)
    return events.filter(e => 
      e.date.getDate() === date.getDate() &&
      e.date.getMonth() === date.getMonth() &&
      e.date.getFullYear() === date.getFullYear()
    )
  }

  const isToday = (day: number) => {
    const today = new Date()
    return (
      day === today.getDate() &&
      month === today.getMonth() &&
      year === today.getFullYear()
    )
  }

  const isSelected = (day: number) => {
    if (!selectedDate) return false
    return (
      day === selectedDate.getDate() &&
      month === selectedDate.getMonth() &&
      year === selectedDate.getFullYear()
    )
  }

  const addEvent = () => {
    if (!selectedDate || !newEvent.title.trim()) return

    const event: Event = {
      id: Date.now().toString(),
      title: newEvent.title,
      date: selectedDate,
      time: newEvent.time,
      location: newEvent.location || undefined,
      color: newEvent.color,
    }

    setEvents([...events, event])
    setNewEvent({ title: '', time: '12:00', location: '', color: COLORS[0] })
    setShowAddEvent(false)
  }

  const updateEvent = () => {
    if (!editingEvent) return
    setEvents(events.map(e => e.id === editingEvent.id ? editingEvent : e))
    setEditingEvent(null)
  }

  const deleteEvent = (id: string) => {
    setEvents(events.filter(e => e.id !== id))
  }

  const selectedDateEvents = selectedDate 
    ? events.filter(e => 
        e.date.getDate() === selectedDate.getDate() &&
        e.date.getMonth() === selectedDate.getMonth() &&
        e.date.getFullYear() === selectedDate.getFullYear()
      )
    : []

  // Build calendar grid
  const calendarDays = []
  
  // Previous month days
  for (let i = firstDayOfMonth - 1; i >= 0; i--) {
    calendarDays.push({ day: daysInPrevMonth - i, currentMonth: false, offset: -1 })
  }
  
  // Current month days
  for (let i = 1; i <= daysInMonth; i++) {
    calendarDays.push({ day: i, currentMonth: true, offset: 0 })
  }
  
  // Next month days
  const remainingDays = 42 - calendarDays.length
  for (let i = 1; i <= remainingDays; i++) {
    calendarDays.push({ day: i, currentMonth: false, offset: 1 })
  }

  return (
    <div className="flex h-full bg-[#0d0a12] text-white">
      {/* Calendar Grid */}
      <div className="flex-1 flex flex-col p-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold">
              {MONTHS[month]} {year}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={goToToday}
              className="px-3 py-1.5 text-sm bg-purple-500/30 hover:bg-purple-500/50 rounded-lg transition-colors"
            >
              Today
            </button>
            <button
              onClick={prevMonth}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={nextMonth}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Day Headers */}
        <div className="grid grid-cols-7 gap-1 mb-2">
          {DAYS.map(day => (
            <div key={day} className="text-center text-sm text-gray-500 py-2">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-1 flex-1">
          {calendarDays.map((item, index) => {
            const dayEvents = getDayEvents(item.day, item.offset)
            return (
              <button
                key={index}
                onClick={() => {
                  if (item.currentMonth) {
                    setSelectedDate(new Date(year, month, item.day))
                  }
                }}
                className={`p-2 rounded-lg text-left transition-colors min-h-[80px] ${
                  item.currentMonth
                    ? isSelected(item.day)
                      ? 'bg-purple-500/30 border border-purple-500'
                      : isToday(item.day)
                        ? 'bg-purple-500/20'
                        : 'hover:bg-white/5'
                    : 'opacity-30'
                }`}
              >
                <span className={`text-sm ${isToday(item.day) && item.currentMonth ? 'text-purple-400 font-bold' : ''}`}>
                  {item.day}
                </span>
                <div className="mt-1 space-y-0.5">
                  {dayEvents.slice(0, 2).map(event => (
                    <div
                      key={event.id}
                      className={`text-xs truncate px-1 py-0.5 rounded ${event.color} bg-opacity-30`}
                    >
                      {event.title}
                    </div>
                  ))}
                  {dayEvents.length > 2 && (
                    <div className="text-xs text-gray-500">+{dayEvents.length - 2} more</div>
                  )}
                </div>
              </button>
            )
          })}
        </div>
      </div>

      {/* Sidebar */}
      <div className="w-80 bg-[#12101a] border-l border-purple-500/20 flex flex-col">
        <div className="p-4 border-b border-purple-500/20">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">
              {selectedDate 
                ? selectedDate.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })
                : 'Select a date'
              }
            </h3>
            {selectedDate && (
              <button
                onClick={() => setShowAddEvent(true)}
                className="p-2 bg-purple-500 hover:bg-purple-600 rounded-lg transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Events List */}
        <div className="flex-1 overflow-y-auto p-4">
          {selectedDateEvents.length === 0 ? (
            <div className="text-center text-gray-500 py-8">
              <CalendarIcon className="w-12 h-12 mx-auto mb-2 opacity-30" />
              <p className="text-sm">No events for this day</p>
            </div>
          ) : (
            <div className="space-y-3">
              {selectedDateEvents.map(event => (
                <div
                  key={event.id}
                  className="bg-black/20 rounded-xl p-3 border border-purple-500/20"
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-1 h-full min-h-[40px] rounded-full ${event.color}`} />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium truncate">{event.title}</h4>
                      <div className="flex items-center gap-2 text-sm text-gray-400 mt-1">
                        <Clock className="w-3 h-3" />
                        <span>{event.time}</span>
                      </div>
                      {event.location && (
                        <div className="flex items-center gap-2 text-sm text-gray-400 mt-0.5">
                          <MapPin className="w-3 h-3" />
                          <span className="truncate">{event.location}</span>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-1">
                      <button
                        onClick={() => setEditingEvent(event)}
                        className="p-1 hover:bg-white/10 rounded"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => deleteEvent(event.id)}
                        className="p-1 hover:bg-white/10 rounded text-red-400"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Add Event Modal */}
        {showAddEvent && selectedDate && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-[#1a1625] rounded-2xl p-6 w-80 border border-purple-500/30">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Add Event</h3>
                <button onClick={() => setShowAddEvent(false)} className="p-1 hover:bg-white/10 rounded">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-4">
                <input
                  type="text"
                  value={newEvent.title}
                  onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                  placeholder="Event title"
                  className="w-full bg-black/30 rounded-lg px-4 py-2 outline-none border border-purple-500/30 focus:border-purple-500"
                />
                <input
                  type="time"
                  value={newEvent.time}
                  onChange={(e) => setNewEvent({ ...newEvent, time: e.target.value })}
                  className="w-full bg-black/30 rounded-lg px-4 py-2 outline-none border border-purple-500/30 focus:border-purple-500"
                />
                <input
                  type="text"
                  value={newEvent.location}
                  onChange={(e) => setNewEvent({ ...newEvent, location: e.target.value })}
                  placeholder="Location (optional)"
                  className="w-full bg-black/30 rounded-lg px-4 py-2 outline-none border border-purple-500/30 focus:border-purple-500"
                />
                <div className="flex gap-2">
                  {COLORS.map(color => (
                    <button
                      key={color}
                      onClick={() => setNewEvent({ ...newEvent, color })}
                      className={`w-8 h-8 rounded-full ${color} ${newEvent.color === color ? 'ring-2 ring-white ring-offset-2 ring-offset-[#1a1625]' : ''}`}
                    />
                  ))}
                </div>
                <button
                  onClick={addEvent}
                  className="w-full py-2 bg-purple-500 hover:bg-purple-600 rounded-lg font-medium transition-colors"
                >
                  Add Event
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Edit Event Modal */}
        {editingEvent && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-[#1a1625] rounded-2xl p-6 w-80 border border-purple-500/30">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Edit Event</h3>
                <button onClick={() => setEditingEvent(null)} className="p-1 hover:bg-white/10 rounded">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-4">
                <input
                  type="text"
                  value={editingEvent.title}
                  onChange={(e) => setEditingEvent({ ...editingEvent, title: e.target.value })}
                  className="w-full bg-black/30 rounded-lg px-4 py-2 outline-none border border-purple-500/30 focus:border-purple-500"
                />
                <input
                  type="time"
                  value={editingEvent.time}
                  onChange={(e) => setEditingEvent({ ...editingEvent, time: e.target.value })}
                  className="w-full bg-black/30 rounded-lg px-4 py-2 outline-none border border-purple-500/30 focus:border-purple-500"
                />
                <input
                  type="text"
                  value={editingEvent.location || ''}
                  onChange={(e) => setEditingEvent({ ...editingEvent, location: e.target.value })}
                  placeholder="Location (optional)"
                  className="w-full bg-black/30 rounded-lg px-4 py-2 outline-none border border-purple-500/30 focus:border-purple-500"
                />
                <button
                  onClick={updateEvent}
                  className="w-full py-2 bg-purple-500 hover:bg-purple-600 rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4" /> Save Changes
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
