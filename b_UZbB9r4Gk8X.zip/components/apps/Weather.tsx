"use client"

import { useState, useEffect } from 'react'
import { 
  Cloud, Sun, CloudRain, CloudSnow, Wind, Droplets, 
  Thermometer, MapPin, Search, RefreshCw, Sunrise, Sunset,
  CloudLightning, CloudFog, Eye
} from 'lucide-react'

interface WeatherData {
  location: string
  temp: number
  feelsLike: number
  condition: string
  humidity: number
  wind: number
  visibility: number
  uvIndex: number
  sunrise: string
  sunset: string
  forecast: { day: string; high: number; low: number; condition: string }[]
  hourly: { time: string; temp: number; condition: string }[]
}

const mockWeather: WeatherData = {
  location: 'San Francisco, CA',
  temp: 18,
  feelsLike: 16,
  condition: 'Partly Cloudy',
  humidity: 72,
  wind: 15,
  visibility: 10,
  uvIndex: 3,
  sunrise: '6:42 AM',
  sunset: '7:58 PM',
  forecast: [
    { day: 'Today', high: 20, low: 14, condition: 'cloudy' },
    { day: 'Tue', high: 22, low: 15, condition: 'sunny' },
    { day: 'Wed', high: 19, low: 13, condition: 'rainy' },
    { day: 'Thu', high: 17, low: 12, condition: 'rainy' },
    { day: 'Fri', high: 21, low: 14, condition: 'cloudy' },
    { day: 'Sat', high: 24, low: 16, condition: 'sunny' },
    { day: 'Sun', high: 23, low: 15, condition: 'sunny' },
  ],
  hourly: [
    { time: 'Now', temp: 18, condition: 'cloudy' },
    { time: '1 PM', temp: 19, condition: 'cloudy' },
    { time: '2 PM', temp: 20, condition: 'sunny' },
    { time: '3 PM', temp: 20, condition: 'sunny' },
    { time: '4 PM', temp: 19, condition: 'cloudy' },
    { time: '5 PM', temp: 18, condition: 'cloudy' },
    { time: '6 PM', temp: 17, condition: 'cloudy' },
    { time: '7 PM', temp: 16, condition: 'cloudy' },
  ]
}

const getWeatherIcon = (condition: string, size: string = 'w-8 h-8') => {
  const icons: Record<string, React.ReactNode> = {
    sunny: <Sun className={`${size} text-yellow-400`} />,
    cloudy: <Cloud className={`${size} text-gray-400`} />,
    rainy: <CloudRain className={`${size} text-blue-400`} />,
    snowy: <CloudSnow className={`${size} text-blue-200`} />,
    stormy: <CloudLightning className={`${size} text-yellow-500`} />,
    foggy: <CloudFog className={`${size} text-gray-500`} />,
  }
  return icons[condition] || icons.cloudy
}

export default function Weather() {
  const [weather, setWeather] = useState<WeatherData>(mockWeather)
  const [searchQuery, setSearchQuery] = useState('')
  const [loading, setLoading] = useState(false)
  const [unit, setUnit] = useState<'C' | 'F'>('C')

  const convertTemp = (temp: number) => {
    if (unit === 'F') return Math.round((temp * 9/5) + 32)
    return temp
  }

  const handleSearch = () => {
    if (!searchQuery.trim()) return
    setLoading(true)
    // Simulate API call
    setTimeout(() => {
      setWeather({
        ...mockWeather,
        location: searchQuery,
        temp: Math.floor(Math.random() * 20) + 10,
      })
      setLoading(false)
    }, 1000)
  }

  const refresh = () => {
    setLoading(true)
    setTimeout(() => setLoading(false), 1000)
  }

  return (
    <div className="h-full bg-gradient-to-br from-[#1a1625] via-[#1e1a2e] to-[#251d35] text-white overflow-y-auto">
      {/* Header */}
      <div className="p-4 border-b border-purple-500/20">
        <div className="flex items-center gap-2">
          <div className="flex-1 flex items-center bg-black/30 rounded-lg px-3 py-2 gap-2 border border-purple-500/30">
            <Search className="w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="Search location..."
              className="flex-1 bg-transparent outline-none text-sm"
            />
          </div>
          <button
            onClick={refresh}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => setUnit(unit === 'C' ? 'F' : 'C')}
            className="px-3 py-2 bg-purple-500/30 hover:bg-purple-500/50 rounded-lg text-sm font-medium transition-colors"
          >
            {unit === 'C' ? 'C' : 'F'}
          </button>
        </div>
      </div>

      <div className="p-6">
        {/* Current Weather */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 text-gray-400 mb-2">
            <MapPin className="w-4 h-4" />
            <span>{weather.location}</span>
          </div>
          <div className="flex items-center justify-center gap-4 mb-2">
            {getWeatherIcon('cloudy', 'w-16 h-16')}
            <span className="text-7xl font-light">{convertTemp(weather.temp)}</span>
            <span className="text-2xl text-gray-400 self-start mt-4">{unit}</span>
          </div>
          <p className="text-xl text-gray-300">{weather.condition}</p>
          <p className="text-sm text-gray-500">Feels like {convertTemp(weather.feelsLike)}{unit}</p>
        </div>

        {/* Hourly Forecast */}
        <div className="bg-black/20 rounded-2xl p-4 mb-4 border border-purple-500/20">
          <h3 className="text-sm font-medium text-gray-400 mb-3">Hourly Forecast</h3>
          <div className="flex gap-4 overflow-x-auto pb-2">
            {weather.hourly.map((hour, i) => (
              <div key={i} className="flex flex-col items-center gap-2 min-w-[60px]">
                <span className="text-xs text-gray-500">{hour.time}</span>
                {getWeatherIcon(hour.condition, 'w-6 h-6')}
                <span className="text-sm font-medium">{convertTemp(hour.temp)}{unit}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Weekly Forecast */}
        <div className="bg-black/20 rounded-2xl p-4 mb-4 border border-purple-500/20">
          <h3 className="text-sm font-medium text-gray-400 mb-3">7-Day Forecast</h3>
          <div className="space-y-3">
            {weather.forecast.map((day, i) => (
              <div key={i} className="flex items-center gap-4">
                <span className="w-12 text-sm">{day.day}</span>
                {getWeatherIcon(day.condition, 'w-6 h-6')}
                <div className="flex-1 flex items-center gap-2">
                  <span className="text-sm">{convertTemp(day.low)}{unit}</span>
                  <div className="flex-1 h-1 bg-gray-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-blue-400 to-orange-400"
                      style={{ 
                        width: `${((day.high - day.low) / 20) * 100}%`,
                        marginLeft: `${((day.low - 10) / 20) * 100}%`
                      }}
                    />
                  </div>
                  <span className="text-sm">{convertTemp(day.high)}{unit}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Weather Details */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-black/20 rounded-xl p-4 border border-purple-500/20">
            <div className="flex items-center gap-2 text-gray-400 mb-2">
              <Sunrise className="w-4 h-4" />
              <span className="text-xs">Sunrise</span>
            </div>
            <span className="text-lg font-medium">{weather.sunrise}</span>
          </div>
          <div className="bg-black/20 rounded-xl p-4 border border-purple-500/20">
            <div className="flex items-center gap-2 text-gray-400 mb-2">
              <Sunset className="w-4 h-4" />
              <span className="text-xs">Sunset</span>
            </div>
            <span className="text-lg font-medium">{weather.sunset}</span>
          </div>
          <div className="bg-black/20 rounded-xl p-4 border border-purple-500/20">
            <div className="flex items-center gap-2 text-gray-400 mb-2">
              <Droplets className="w-4 h-4" />
              <span className="text-xs">Humidity</span>
            </div>
            <span className="text-lg font-medium">{weather.humidity}%</span>
          </div>
          <div className="bg-black/20 rounded-xl p-4 border border-purple-500/20">
            <div className="flex items-center gap-2 text-gray-400 mb-2">
              <Wind className="w-4 h-4" />
              <span className="text-xs">Wind</span>
            </div>
            <span className="text-lg font-medium">{weather.wind} km/h</span>
          </div>
          <div className="bg-black/20 rounded-xl p-4 border border-purple-500/20">
            <div className="flex items-center gap-2 text-gray-400 mb-2">
              <Eye className="w-4 h-4" />
              <span className="text-xs">Visibility</span>
            </div>
            <span className="text-lg font-medium">{weather.visibility} km</span>
          </div>
          <div className="bg-black/20 rounded-xl p-4 border border-purple-500/20">
            <div className="flex items-center gap-2 text-gray-400 mb-2">
              <Sun className="w-4 h-4" />
              <span className="text-xs">UV Index</span>
            </div>
            <span className="text-lg font-medium">{weather.uvIndex} Low</span>
          </div>
        </div>
      </div>
    </div>
  )
}
