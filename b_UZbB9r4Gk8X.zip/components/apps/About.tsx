'use client'

import { Github, Globe, Heart, Code, Sparkles } from 'lucide-react'

export function About() {
  return (
    <div className="h-full bg-gradient-to-b from-[#1a0a2e] to-background overflow-auto">
      <div className="max-w-2xl mx-auto p-8">
        {/* Logo and title */}
        <div className="text-center mb-12">
          <div className="inline-flex h-24 w-24 items-center justify-center rounded-2xl bg-primary/20 mb-6 glow">
            <span className="text-5xl font-bold text-primary">W11</span>
          </div>
          <h1 className="text-4xl font-bold text-foreground glow-text">Win11 Rebirth</h1>
          <p className="text-muted-foreground mt-2">Version 1.0.0</p>
        </div>

        {/* Description */}
        <div className="glass rounded-2xl p-6 mb-8">
          <p className="text-foreground leading-relaxed">
            Win11 Rebirth is a web-based Windows 11 experience built with modern technologies.
            It features a fully functional desktop environment with a working browser, file explorer,
            terminal, and more. Designed with a beautiful purple theme inspired by ViroNexus.
          </p>
        </div>

        {/* Features */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            Features
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {[
              'Window Management',
              'Working Browser',
              'File Explorer',
              'Terminal',
              'Settings & Customization',
              'Calculator',
              'Music Player',
              'Photos App',
              'Notepad',
              'Start Menu',
              'Taskbar',
              'Notification Center',
            ].map((feature) => (
              <div key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                {feature}
              </div>
            ))}
          </div>
        </div>

        {/* Tech stack */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
            <Code className="h-5 w-5 text-primary" />
            Built With
          </h2>
          <div className="flex flex-wrap gap-2">
            {['Next.js', 'React', 'TypeScript', 'Tailwind CSS', 'Zustand', 'Lucide Icons'].map(
              (tech) => (
                <span
                  key={tech}
                  className="px-3 py-1 rounded-full bg-secondary text-sm text-foreground"
                >
                  {tech}
                </span>
              )
            )}
          </div>
        </div>

        {/* Developer */}
        <div className="glass rounded-2xl p-6 mb-8">
          <h2 className="text-xl font-semibold text-foreground mb-4">Developer</h2>
          <div className="flex items-center gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/20">
              <span className="text-3xl">💜</span>
            </div>
            <div>
              <h3 className="text-lg font-medium text-foreground">v/admin (viroda1)</h3>
              <p className="text-muted-foreground">Creator of ViroNexus</p>
            </div>
          </div>
        </div>

        {/* Links */}
        <div className="flex items-center justify-center gap-4">
          <a
            href="https://github.com/viroda1"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
          >
            <Github className="h-5 w-5 text-foreground" />
            <span className="text-sm text-foreground">GitHub</span>
          </a>
          <a
            href="https://vironexus.rf.gd"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
          >
            <Globe className="h-5 w-5 text-foreground" />
            <span className="text-sm text-foreground">ViroNexus</span>
          </a>
        </div>

        {/* Footer */}
        <div className="text-center mt-12 text-sm text-muted-foreground">
          <p className="flex items-center justify-center gap-1">
            Made with <Heart className="h-4 w-4 text-red-500 fill-red-500" /> by v/admin
          </p>
          <p className="mt-2">2024 ViroNexus. All rights reserved.</p>
        </div>
      </div>
    </div>
  )
}
