"use client"

import { useState, useRef, useEffect } from 'react'
import { 
  Pencil, Eraser, Square, Circle, Minus, Pipette,
  Undo2, Redo2, Trash2, Download, Plus, PaintBucket
} from 'lucide-react'

type Tool = 'pencil' | 'eraser' | 'rectangle' | 'circle' | 'line' | 'fill' | 'picker'

const COLORS = [
  '#ffffff', '#000000', '#ff0000', '#00ff00', '#0000ff',
  '#ffff00', '#ff00ff', '#00ffff', '#ff8800', '#8800ff',
  '#a855f7', '#ec4899', '#14b8a6', '#84cc16', '#f97316',
]

const SIZES = [2, 4, 8, 12, 20, 32]

export default function Paint() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isDrawing, setIsDrawing] = useState(false)
  const [tool, setTool] = useState<Tool>('pencil')
  const [color, setColor] = useState('#a855f7')
  const [brushSize, setBrushSize] = useState(4)
  const [history, setHistory] = useState<ImageData[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const [startPos, setStartPos] = useState<{ x: number; y: number } | null>(null)
  const [customColors, setCustomColors] = useState<string[]>([])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    // Set canvas size
    canvas.width = canvas.offsetWidth
    canvas.height = canvas.offsetHeight

    // Fill with white
    ctx.fillStyle = '#1a1625'
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Save initial state
    saveToHistory()
  }, [])

  const saveToHistory = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
    const newHistory = history.slice(0, historyIndex + 1)
    newHistory.push(imageData)
    setHistory(newHistory)
    setHistoryIndex(newHistory.length - 1)
  }

  const undo = () => {
    if (historyIndex <= 0) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const newIndex = historyIndex - 1
    ctx.putImageData(history[newIndex], 0, 0)
    setHistoryIndex(newIndex)
  }

  const redo = () => {
    if (historyIndex >= history.length - 1) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const newIndex = historyIndex + 1
    ctx.putImageData(history[newIndex], 0, 0)
    setHistoryIndex(newIndex)
  }

  const clearCanvas = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    ctx.fillStyle = '#1a1625'
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    saveToHistory()
  }

  const downloadCanvas = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const link = document.createElement('a')
    link.download = 'rebirth-paint.png'
    link.href = canvas.toDataURL()
    link.click()
  }

  const getPos = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return { x: 0, y: 0 }

    const rect = canvas.getBoundingClientRect()
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    }
  }

  const floodFill = (startX: number, startY: number, fillColor: string) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
    const data = imageData.data

    const startIdx = (startY * canvas.width + startX) * 4
    const startR = data[startIdx]
    const startG = data[startIdx + 1]
    const startB = data[startIdx + 2]

    // Parse fill color
    const fillR = parseInt(fillColor.slice(1, 3), 16)
    const fillG = parseInt(fillColor.slice(3, 5), 16)
    const fillB = parseInt(fillColor.slice(5, 7), 16)

    if (startR === fillR && startG === fillG && startB === fillB) return

    const stack: [number, number][] = [[startX, startY]]
    const visited = new Set<string>()

    while (stack.length > 0) {
      const [x, y] = stack.pop()!
      const key = `${x},${y}`

      if (visited.has(key)) continue
      if (x < 0 || x >= canvas.width || y < 0 || y >= canvas.height) continue

      const idx = (y * canvas.width + x) * 4
      if (data[idx] !== startR || data[idx + 1] !== startG || data[idx + 2] !== startB) continue

      visited.add(key)
      data[idx] = fillR
      data[idx + 1] = fillG
      data[idx + 2] = fillB
      data[idx + 3] = 255

      stack.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1])
    }

    ctx.putImageData(imageData, 0, 0)
  }

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const pos = getPos(e)
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    if (tool === 'picker') {
      const imageData = ctx.getImageData(pos.x, pos.y, 1, 1)
      const [r, g, b] = imageData.data
      const hex = `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`
      setColor(hex)
      setTool('pencil')
      return
    }

    if (tool === 'fill') {
      floodFill(Math.floor(pos.x), Math.floor(pos.y), color)
      saveToHistory()
      return
    }

    setIsDrawing(true)
    setStartPos(pos)

    if (tool === 'pencil' || tool === 'eraser') {
      ctx.beginPath()
      ctx.moveTo(pos.x, pos.y)
      ctx.lineCap = 'round'
      ctx.lineJoin = 'round'
      ctx.lineWidth = brushSize
      ctx.strokeStyle = tool === 'eraser' ? '#1a1625' : color
    }
  }

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return

    const pos = getPos(e)
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    if (tool === 'pencil' || tool === 'eraser') {
      ctx.lineTo(pos.x, pos.y)
      ctx.stroke()
    }
  }

  const stopDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return

    const pos = getPos(e)
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    if (tool === 'rectangle' && startPos) {
      ctx.strokeStyle = color
      ctx.lineWidth = brushSize
      ctx.strokeRect(startPos.x, startPos.y, pos.x - startPos.x, pos.y - startPos.y)
    }

    if (tool === 'circle' && startPos) {
      const radius = Math.sqrt(
        Math.pow(pos.x - startPos.x, 2) + Math.pow(pos.y - startPos.y, 2)
      )
      ctx.strokeStyle = color
      ctx.lineWidth = brushSize
      ctx.beginPath()
      ctx.arc(startPos.x, startPos.y, radius, 0, Math.PI * 2)
      ctx.stroke()
    }

    if (tool === 'line' && startPos) {
      ctx.strokeStyle = color
      ctx.lineWidth = brushSize
      ctx.lineCap = 'round'
      ctx.beginPath()
      ctx.moveTo(startPos.x, startPos.y)
      ctx.lineTo(pos.x, pos.y)
      ctx.stroke()
    }

    setIsDrawing(false)
    setStartPos(null)
    saveToHistory()
  }

  const addCustomColor = () => {
    if (!customColors.includes(color)) {
      setCustomColors([...customColors.slice(-4), color])
    }
  }

  const tools = [
    { id: 'pencil', icon: <Pencil className="w-4 h-4" />, name: 'Pencil' },
    { id: 'eraser', icon: <Eraser className="w-4 h-4" />, name: 'Eraser' },
    { id: 'line', icon: <Minus className="w-4 h-4" />, name: 'Line' },
    { id: 'rectangle', icon: <Square className="w-4 h-4" />, name: 'Rectangle' },
    { id: 'circle', icon: <Circle className="w-4 h-4" />, name: 'Circle' },
    { id: 'fill', icon: <PaintBucket className="w-4 h-4" />, name: 'Fill' },
    { id: 'picker', icon: <Pipette className="w-4 h-4" />, name: 'Color Picker' },
  ]

  return (
    <div className="flex flex-col h-full bg-[#0d0a12] text-white">
      {/* Toolbar */}
      <div className="flex items-center gap-4 p-3 bg-[#12101a] border-b border-purple-500/20">
        {/* Tools */}
        <div className="flex items-center gap-1 bg-black/30 rounded-lg p-1">
          {tools.map(t => (
            <button
              key={t.id}
              onClick={() => setTool(t.id as Tool)}
              className={`p-2 rounded-lg transition-colors ${
                tool === t.id ? 'bg-purple-500/50 text-purple-200' : 'hover:bg-white/10'
              }`}
              title={t.name}
            >
              {t.icon}
            </button>
          ))}
        </div>

        {/* Separator */}
        <div className="w-px h-8 bg-purple-500/30" />

        {/* Brush Size */}
        <div className="flex items-center gap-2">
          {SIZES.map(size => (
            <button
              key={size}
              onClick={() => setBrushSize(size)}
              className={`flex items-center justify-center w-8 h-8 rounded-lg transition-colors ${
                brushSize === size ? 'bg-purple-500/50' : 'hover:bg-white/10'
              }`}
            >
              <div 
                className="rounded-full bg-white"
                style={{ width: Math.min(size, 16), height: Math.min(size, 16) }}
              />
            </button>
          ))}
        </div>

        {/* Separator */}
        <div className="w-px h-8 bg-purple-500/30" />

        {/* Actions */}
        <div className="flex items-center gap-1">
          <button
            onClick={undo}
            disabled={historyIndex <= 0}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors disabled:opacity-30"
            title="Undo"
          >
            <Undo2 className="w-4 h-4" />
          </button>
          <button
            onClick={redo}
            disabled={historyIndex >= history.length - 1}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors disabled:opacity-30"
            title="Redo"
          >
            <Redo2 className="w-4 h-4" />
          </button>
          <button
            onClick={clearCanvas}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors text-red-400"
            title="Clear"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            onClick={downloadCanvas}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors text-green-400"
            title="Download"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1" />

        {/* Current Color */}
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-400">Color:</span>
          <div 
            className="w-8 h-8 rounded-lg border-2 border-white/30"
            style={{ backgroundColor: color }}
          />
          <input
            type="color"
            value={color}
            onChange={(e) => setColor(e.target.value)}
            className="w-8 h-8 rounded cursor-pointer"
          />
          <button
            onClick={addCustomColor}
            className="p-1 hover:bg-white/10 rounded"
            title="Save color"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Color Palette Sidebar */}
        <div className="w-14 bg-[#12101a] border-r border-purple-500/20 p-2 flex flex-col gap-2">
          <div className="grid grid-cols-2 gap-1">
            {COLORS.map(c => (
              <button
                key={c}
                onClick={() => setColor(c)}
                className={`w-5 h-5 rounded ${color === c ? 'ring-2 ring-white' : ''}`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
          {customColors.length > 0 && (
            <>
              <div className="w-full h-px bg-purple-500/30" />
              <div className="grid grid-cols-2 gap-1">
                {customColors.map((c, i) => (
                  <button
                    key={i}
                    onClick={() => setColor(c)}
                    className={`w-5 h-5 rounded ${color === c ? 'ring-2 ring-white' : ''}`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </>
          )}
        </div>

        {/* Canvas */}
        <div className="flex-1 p-4 overflow-auto">
          <canvas
            ref={canvasRef}
            className="w-full h-full rounded-lg cursor-crosshair"
            style={{ imageRendering: 'pixelated' }}
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
          />
        </div>
      </div>
    </div>
  )
}
