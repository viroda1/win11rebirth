'use client'

import { useState } from 'react'
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  Repeat,
  Shuffle,
  Heart,
  ListMusic,
  Music,
} from 'lucide-react'

interface Track {
  id: string
  title: string
  artist: string
  album: string
  duration: string
}

const mockPlaylist: Track[] = [
  { id: '1', title: 'Digital Dreams', artist: 'ViroNexus', album: 'Rebirth', duration: '3:45' },
  { id: '2', title: 'Neon Nights', artist: 'CyberWave', album: 'Synthetics', duration: '4:12' },
  { id: '3', title: 'Purple Rain', artist: 'v/admin', album: 'Win11 Rebirth OST', duration: '3:28' },
  { id: '4', title: 'Binary Sunset', artist: 'ElectroDream', album: 'Code Poetry', duration: '5:01' },
  { id: '5', title: 'Virtual Reality', artist: 'NeonPulse', album: 'Future Waves', duration: '4:33' },
  { id: '6', title: 'Midnight Protocol', artist: 'CyberWave', album: 'Synthetics', duration: '3:58' },
]

export function MusicPlayer() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTrack, setCurrentTrack] = useState<Track>(mockPlaylist[0])
  const [progress, setProgress] = useState(0)
  const [volume, setVolume] = useState(75)
  const [shuffle, setShuffle] = useState(false)
  const [repeat, setRepeat] = useState(false)
  const [liked, setLiked] = useState<string[]>([])

  const toggleLike = (id: string) => {
    setLiked(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    )
  }

  const playTrack = (track: Track) => {
    setCurrentTrack(track)
    setIsPlaying(true)
    setProgress(0)
  }

  const nextTrack = () => {
    const currentIndex = mockPlaylist.findIndex(t => t.id === currentTrack.id)
    const nextIndex = shuffle
      ? Math.floor(Math.random() * mockPlaylist.length)
      : (currentIndex + 1) % mockPlaylist.length
    setCurrentTrack(mockPlaylist[nextIndex])
    setProgress(0)
  }

  const prevTrack = () => {
    const currentIndex = mockPlaylist.findIndex(t => t.id === currentTrack.id)
    const prevIndex = currentIndex === 0 ? mockPlaylist.length - 1 : currentIndex - 1
    setCurrentTrack(mockPlaylist[prevIndex])
    setProgress(0)
  }

  return (
    <div className="flex flex-col h-full bg-gradient-to-b from-[#1a0a2e] to-background">
      {/* Album art area */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="relative">
          {/* Album cover */}
          <div className="relative h-64 w-64 rounded-2xl bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center shadow-2xl">
            <Music className="h-24 w-24 text-primary/50" />
            {/* Glow effect */}
            <div className="absolute inset-0 rounded-2xl bg-primary/20 blur-2xl -z-10" />
          </div>
          
          {/* Now playing info */}
          <div className="text-center mt-6">
            <h2 className="text-2xl font-bold text-foreground">{currentTrack.title}</h2>
            <p className="text-muted-foreground mt-1">{currentTrack.artist}</p>
            <p className="text-sm text-muted-foreground/70">{currentTrack.album}</p>
          </div>
        </div>
      </div>

      {/* Progress bar */}
      <div className="px-8">
        <div className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground w-10">
            {Math.floor(progress / 60)}:{String(progress % 60).padStart(2, '0')}
          </span>
          <input
            type="range"
            min="0"
            max="100"
            value={progress}
            onChange={(e) => setProgress(parseInt(e.target.value))}
            className="flex-1 h-1 bg-secondary rounded-full appearance-none cursor-pointer accent-primary"
          />
          <span className="text-xs text-muted-foreground w-10">{currentTrack.duration}</span>
        </div>
      </div>

      {/* Controls */}
      <div className="p-8 pt-4">
        <div className="flex items-center justify-center gap-6">
          <button
            onClick={() => setShuffle(!shuffle)}
            className={`p-2 rounded-full transition-colors ${
              shuffle ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Shuffle className="h-5 w-5" />
          </button>
          <button
            onClick={prevTrack}
            className="p-2 text-foreground hover:text-primary transition-colors"
          >
            <SkipBack className="h-6 w-6" />
          </button>
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
          >
            {isPlaying ? (
              <Pause className="h-6 w-6" />
            ) : (
              <Play className="h-6 w-6 ml-1" />
            )}
          </button>
          <button
            onClick={nextTrack}
            className="p-2 text-foreground hover:text-primary transition-colors"
          >
            <SkipForward className="h-6 w-6" />
          </button>
          <button
            onClick={() => setRepeat(!repeat)}
            className={`p-2 rounded-full transition-colors ${
              repeat ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Repeat className="h-5 w-5" />
          </button>
        </div>

        {/* Volume */}
        <div className="flex items-center justify-center gap-3 mt-6">
          <Volume2 className="h-4 w-4 text-muted-foreground" />
          <input
            type="range"
            min="0"
            max="100"
            value={volume}
            onChange={(e) => setVolume(parseInt(e.target.value))}
            className="w-32 h-1 bg-secondary rounded-full appearance-none cursor-pointer accent-primary"
          />
        </div>
      </div>

      {/* Playlist */}
      <div className="border-t border-border">
        <div className="flex items-center justify-between px-4 py-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <ListMusic className="h-4 w-4" />
            <span>Playlist</span>
          </div>
        </div>
        <div className="max-h-48 overflow-auto">
          {mockPlaylist.map((track) => (
            <button
              key={track.id}
              onClick={() => playTrack(track)}
              className={`flex items-center gap-3 w-full px-4 py-2 hover:bg-secondary/50 transition-colors ${
                currentTrack.id === track.id ? 'bg-secondary' : ''
              }`}
            >
              <div className="flex h-10 w-10 items-center justify-center rounded bg-primary/20">
                {currentTrack.id === track.id && isPlaying ? (
                  <div className="flex items-end gap-0.5 h-4">
                    <div className="w-1 h-2 bg-primary animate-pulse" />
                    <div className="w-1 h-4 bg-primary animate-pulse delay-75" />
                    <div className="w-1 h-3 bg-primary animate-pulse delay-150" />
                  </div>
                ) : (
                  <Music className="h-4 w-4 text-primary" />
                )}
              </div>
              <div className="flex-1 text-left">
                <div className={`text-sm ${currentTrack.id === track.id ? 'text-primary font-medium' : 'text-foreground'}`}>
                  {track.title}
                </div>
                <div className="text-xs text-muted-foreground">{track.artist}</div>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  toggleLike(track.id)
                }}
                className="p-1"
              >
                <Heart
                  className={`h-4 w-4 transition-colors ${
                    liked.includes(track.id)
                      ? 'fill-primary text-primary'
                      : 'text-muted-foreground hover:text-primary'
                  }`}
                />
              </button>
              <span className="text-xs text-muted-foreground">{track.duration}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
