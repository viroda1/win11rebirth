"use client"

import { useState } from 'react'
import { 
  Search, Download, Star, ChevronRight, Grid3X3, List,
  Gamepad2, Palette, Music, Video, FileText, Code,
  Shield, Zap, Clock, Check, Loader2
} from 'lucide-react'

interface App {
  id: string
  name: string
  developer: string
  icon: React.ReactNode
  rating: number
  reviews: number
  size: string
  category: string
  description: string
  installed: boolean
  installing: boolean
}

const categories = [
  { id: 'all', name: 'All Apps', icon: <Grid3X3 className="w-4 h-4" /> },
  { id: 'games', name: 'Games', icon: <Gamepad2 className="w-4 h-4" /> },
  { id: 'productivity', name: 'Productivity', icon: <FileText className="w-4 h-4" /> },
  { id: 'creative', name: 'Creative', icon: <Palette className="w-4 h-4" /> },
  { id: 'media', name: 'Media', icon: <Video className="w-4 h-4" /> },
  { id: 'developer', name: 'Developer', icon: <Code className="w-4 h-4" /> },
  { id: 'utilities', name: 'Utilities', icon: <Shield className="w-4 h-4" /> },
]

const initialApps: App[] = [
  {
    id: '1',
    name: 'ViroCode',
    developer: 'v/admin',
    icon: <Code className="w-8 h-8" />,
    rating: 4.8,
    reviews: 12500,
    size: '156 MB',
    category: 'developer',
    description: 'A powerful code editor with AI assistance',
    installed: false,
    installing: false,
  },
  {
    id: '2',
    name: 'Pixel Painter',
    developer: 'ViroNexus',
    icon: <Palette className="w-8 h-8" />,
    rating: 4.6,
    reviews: 8200,
    size: '89 MB',
    category: 'creative',
    description: 'Create stunning pixel art and digital illustrations',
    installed: true,
    installing: false,
  },
  {
    id: '3',
    name: 'Beat Studio',
    developer: 'ViroNexus',
    icon: <Music className="w-8 h-8" />,
    rating: 4.7,
    reviews: 6800,
    size: '234 MB',
    category: 'media',
    description: 'Professional music production suite',
    installed: false,
    installing: false,
  },
  {
    id: '4',
    name: 'Cyber Runner',
    developer: 'NeonGames',
    icon: <Gamepad2 className="w-8 h-8" />,
    rating: 4.9,
    reviews: 45000,
    size: '512 MB',
    category: 'games',
    description: 'Fast-paced cyberpunk endless runner',
    installed: false,
    installing: false,
  },
  {
    id: '5',
    name: 'TaskMaster Pro',
    developer: 'ProductivityCo',
    icon: <FileText className="w-8 h-8" />,
    rating: 4.5,
    reviews: 15600,
    size: '45 MB',
    category: 'productivity',
    description: 'Advanced task management and organization',
    installed: true,
    installing: false,
  },
  {
    id: '6',
    name: 'SecureVault',
    developer: 'CyberSec',
    icon: <Shield className="w-8 h-8" />,
    rating: 4.8,
    reviews: 9200,
    size: '28 MB',
    category: 'utilities',
    description: 'Password manager with military-grade encryption',
    installed: false,
    installing: false,
  },
  {
    id: '7',
    name: 'StreamFlix',
    developer: 'MediaCorp',
    icon: <Video className="w-8 h-8" />,
    rating: 4.4,
    reviews: 78000,
    size: '67 MB',
    category: 'media',
    description: 'Stream movies, shows, and live content',
    installed: false,
    installing: false,
  },
  {
    id: '8',
    name: 'SpeedBoost',
    developer: 'ViroNexus',
    icon: <Zap className="w-8 h-8" />,
    rating: 4.3,
    reviews: 4500,
    size: '12 MB',
    category: 'utilities',
    description: 'Optimize system performance and clean junk',
    installed: false,
    installing: false,
  },
]

export default function Store() {
  const [apps, setApps] = useState<App[]>(initialApps)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [selectedApp, setSelectedApp] = useState<App | null>(null)
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')

  const filteredApps = apps.filter(app => {
    const matchesSearch = app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          app.developer.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === 'all' || app.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const installApp = (appId: string) => {
    setApps(apps.map(app => {
      if (app.id === appId) {
        return { ...app, installing: true }
      }
      return app
    }))

    // Simulate installation
    setTimeout(() => {
      setApps(prev => prev.map(app => {
        if (app.id === appId) {
          return { ...app, installing: false, installed: true }
        }
        return app
      }))
    }, 2000)
  }

  const uninstallApp = (appId: string) => {
    setApps(apps.map(app => {
      if (app.id === appId) {
        return { ...app, installed: false }
      }
      return app
    }))
  }

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center gap-0.5">
        {[1, 2, 3, 4, 5].map(star => (
          <Star
            key={star}
            className={`w-3 h-3 ${star <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-600'}`}
          />
        ))}
      </div>
    )
  }

  return (
    <div className="flex h-full bg-[#0d0a12] text-white">
      {/* Sidebar */}
      <div className="w-56 bg-[#12101a] border-r border-purple-500/20 flex flex-col">
        <div className="p-4 border-b border-purple-500/20">
          <h2 className="text-lg font-bold bg-gradient-to-r from-purple-400 to-violet-300 bg-clip-text text-transparent">
            Rebirth Store
          </h2>
        </div>
        <nav className="flex-1 p-2">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                selectedCategory === cat.id
                  ? 'bg-purple-500/30 text-purple-300'
                  : 'hover:bg-white/5 text-gray-400'
              }`}
            >
              {cat.icon}
              <span className="text-sm">{cat.name}</span>
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-purple-500/20">
          <div className="bg-gradient-to-r from-purple-500/20 to-violet-500/20 rounded-lg p-3">
            <p className="text-xs text-gray-400">Installed Apps</p>
            <p className="text-2xl font-bold">{apps.filter(a => a.installed).length}</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Search Header */}
        <div className="p-4 border-b border-purple-500/20 flex items-center gap-4">
          <div className="flex-1 flex items-center bg-black/30 rounded-lg px-4 py-2.5 gap-2 border border-purple-500/30">
            <Search className="w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search apps..."
              className="flex-1 bg-transparent outline-none text-sm"
            />
          </div>
          <div className="flex items-center gap-1 bg-black/30 rounded-lg p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded ${viewMode === 'grid' ? 'bg-purple-500/30' : 'hover:bg-white/10'}`}
            >
              <Grid3X3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded ${viewMode === 'list' ? 'bg-purple-500/30' : 'hover:bg-white/10'}`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* App Grid/List */}
        <div className="flex-1 overflow-y-auto p-4">
          {selectedApp ? (
            /* App Detail View */
            <div>
              <button
                onClick={() => setSelectedApp(null)}
                className="flex items-center gap-2 text-purple-400 hover:text-purple-300 mb-4"
              >
                <ChevronRight className="w-4 h-4 rotate-180" />
                Back to Store
              </button>
              <div className="flex gap-6 mb-6">
                <div className="w-24 h-24 bg-gradient-to-br from-purple-500/30 to-violet-500/30 rounded-2xl flex items-center justify-center text-purple-400">
                  {selectedApp.icon}
                </div>
                <div className="flex-1">
                  <h1 className="text-2xl font-bold mb-1">{selectedApp.name}</h1>
                  <p className="text-gray-400 mb-2">{selectedApp.developer}</p>
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      {renderStars(selectedApp.rating)}
                      <span className="ml-1">{selectedApp.rating}</span>
                    </div>
                    <span className="text-gray-500">{selectedApp.reviews.toLocaleString()} reviews</span>
                    <span className="text-gray-500">{selectedApp.size}</span>
                  </div>
                </div>
                <div>
                  {selectedApp.installed ? (
                    <div className="flex gap-2">
                      <button className="px-6 py-2.5 bg-purple-500 hover:bg-purple-600 rounded-lg font-medium transition-colors">
                        Open
                      </button>
                      <button 
                        onClick={() => uninstallApp(selectedApp.id)}
                        className="px-4 py-2.5 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg font-medium transition-colors"
                      >
                        Uninstall
                      </button>
                    </div>
                  ) : selectedApp.installing ? (
                    <button disabled className="px-6 py-2.5 bg-purple-500/50 rounded-lg font-medium flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Installing...
                    </button>
                  ) : (
                    <button
                      onClick={() => installApp(selectedApp.id)}
                      className="px-6 py-2.5 bg-purple-500 hover:bg-purple-600 rounded-lg font-medium transition-colors flex items-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      Install
                    </button>
                  )}
                </div>
              </div>
              <div className="bg-black/20 rounded-xl p-4 border border-purple-500/20">
                <h3 className="font-medium mb-2">About</h3>
                <p className="text-gray-400 text-sm">{selectedApp.description}</p>
              </div>
            </div>
          ) : viewMode === 'grid' ? (
            /* Grid View */
            <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredApps.map(app => (
                <div
                  key={app.id}
                  onClick={() => setSelectedApp(app)}
                  className="bg-black/20 rounded-xl p-4 border border-purple-500/20 hover:border-purple-500/40 transition-colors cursor-pointer group"
                >
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-500/30 to-violet-500/30 rounded-xl flex items-center justify-center text-purple-400 mb-3 group-hover:from-purple-500/40 group-hover:to-violet-500/40 transition-colors">
                    {app.icon}
                  </div>
                  <h3 className="font-medium truncate">{app.name}</h3>
                  <p className="text-xs text-gray-500 truncate mb-2">{app.developer}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                      <span className="text-xs">{app.rating}</span>
                    </div>
                    {app.installed ? (
                      <span className="text-xs text-green-400 flex items-center gap-1">
                        <Check className="w-3 h-3" /> Installed
                      </span>
                    ) : (
                      <span className="text-xs text-gray-500">{app.size}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            /* List View */
            <div className="space-y-2">
              {filteredApps.map(app => (
                <div
                  key={app.id}
                  onClick={() => setSelectedApp(app)}
                  className="flex items-center gap-4 bg-black/20 rounded-xl p-3 border border-purple-500/20 hover:border-purple-500/40 transition-colors cursor-pointer"
                >
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500/30 to-violet-500/30 rounded-xl flex items-center justify-center text-purple-400">
                    {app.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium truncate">{app.name}</h3>
                    <p className="text-xs text-gray-500">{app.developer}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                    <span className="text-sm">{app.rating}</span>
                  </div>
                  <span className="text-sm text-gray-500 w-20 text-right">{app.size}</span>
                  {app.installed ? (
                    <span className="text-xs text-green-400 flex items-center gap-1 w-20">
                      <Check className="w-3 h-3" /> Installed
                    </span>
                  ) : app.installing ? (
                    <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
                  ) : (
                    <button
                      onClick={(e) => { e.stopPropagation(); installApp(app.id); }}
                      className="p-2 bg-purple-500/30 hover:bg-purple-500/50 rounded-lg transition-colors"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
