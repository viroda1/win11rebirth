'use client'

import { useState } from 'react'
import {
  ChevronRight,
  ChevronDown,
  Folder,
  File,
  Image,
  FileText,
  Music,
  Video,
  HardDrive,
  Home,
  Star,
  Download,
  Clock,
  Trash2,
  Search,
  Grid3X3,
  List,
  ArrowUp,
  ArrowLeft,
  ArrowRight,
} from 'lucide-react'

interface FileItem {
  id: string
  name: string
  type: 'folder' | 'file' | 'image' | 'document' | 'music' | 'video'
  size?: string
  modified?: string
  children?: FileItem[]
}

const mockFileSystem: FileItem[] = [
  {
    id: '1',
    name: 'Desktop',
    type: 'folder',
    children: [
      { id: '1-1', name: 'Projects', type: 'folder', children: [] },
      { id: '1-2', name: 'screenshot.png', type: 'image', size: '2.4 MB', modified: '2024-03-15' },
      { id: '1-3', name: 'notes.txt', type: 'document', size: '4 KB', modified: '2024-03-14' },
    ],
  },
  {
    id: '2',
    name: 'Documents',
    type: 'folder',
    children: [
      { id: '2-1', name: 'Resume.pdf', type: 'document', size: '156 KB', modified: '2024-03-10' },
      { id: '2-2', name: 'Report.docx', type: 'document', size: '2.1 MB', modified: '2024-03-08' },
      { id: '2-3', name: 'Work', type: 'folder', children: [] },
    ],
  },
  {
    id: '3',
    name: 'Downloads',
    type: 'folder',
    children: [
      { id: '3-1', name: 'installer.exe', type: 'file', size: '45 MB', modified: '2024-03-15' },
      { id: '3-2', name: 'album.zip', type: 'file', size: '120 MB', modified: '2024-03-12' },
    ],
  },
  {
    id: '4',
    name: 'Music',
    type: 'folder',
    children: [
      { id: '4-1', name: 'track01.mp3', type: 'music', size: '8 MB', modified: '2024-02-20' },
      { id: '4-2', name: 'track02.mp3', type: 'music', size: '7.5 MB', modified: '2024-02-20' },
    ],
  },
  {
    id: '5',
    name: 'Pictures',
    type: 'folder',
    children: [
      { id: '5-1', name: 'vacation.jpg', type: 'image', size: '3.2 MB', modified: '2024-01-15' },
      { id: '5-2', name: 'profile.png', type: 'image', size: '512 KB', modified: '2024-02-28' },
    ],
  },
  {
    id: '6',
    name: 'Videos',
    type: 'folder',
    children: [
      { id: '6-1', name: 'tutorial.mp4', type: 'video', size: '250 MB', modified: '2024-03-01' },
    ],
  },
]

const quickAccess = [
  { icon: Home, name: 'Home', path: '/' },
  { icon: Star, name: 'Favorites', path: '/favorites' },
  { icon: Download, name: 'Downloads', path: '/downloads' },
  { icon: Clock, name: 'Recent', path: '/recent' },
  { icon: Trash2, name: 'Trash', path: '/trash' },
]

const getIcon = (type: FileItem['type']) => {
  switch (type) {
    case 'folder':
      return Folder
    case 'image':
      return Image
    case 'document':
      return FileText
    case 'music':
      return Music
    case 'video':
      return Video
    default:
      return File
  }
}

const getIconColor = (type: FileItem['type']) => {
  switch (type) {
    case 'folder':
      return 'text-yellow-500'
    case 'image':
      return 'text-green-500'
    case 'document':
      return 'text-blue-500'
    case 'music':
      return 'text-purple-500'
    case 'video':
      return 'text-red-500'
    default:
      return 'text-muted-foreground'
  }
}

export function FileExplorer() {
  const [currentPath, setCurrentPath] = useState<string[]>(['Home'])
  const [selectedItem, setSelectedItem] = useState<string | null>(null)
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [searchQuery, setSearchQuery] = useState('')
  const [expandedFolders, setExpandedFolders] = useState<string[]>(['1', '2'])

  const getCurrentFiles = (): FileItem[] => {
    if (currentPath.length === 1 && currentPath[0] === 'Home') {
      return mockFileSystem
    }
    
    let files = mockFileSystem
    for (let i = 1; i < currentPath.length; i++) {
      const folder = files.find(f => f.name === currentPath[i])
      if (folder?.children) {
        files = folder.children
      }
    }
    return files
  }

  const navigateToFolder = (item: FileItem) => {
    if (item.type === 'folder') {
      setCurrentPath(prev => [...prev, item.name])
      setSelectedItem(null)
    }
  }

  const goBack = () => {
    if (currentPath.length > 1) {
      setCurrentPath(prev => prev.slice(0, -1))
    }
  }

  const goUp = () => {
    goBack()
  }

  const toggleFolder = (id: string) => {
    setExpandedFolders(prev =>
      prev.includes(id)
        ? prev.filter(f => f !== id)
        : [...prev, id]
    )
  }

  const filteredFiles = getCurrentFiles().filter(file =>
    file.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const renderTreeItem = (item: FileItem, depth = 0) => {
    const Icon = getIcon(item.type)
    const isExpanded = expandedFolders.includes(item.id)
    const hasChildren = item.children && item.children.length > 0

    return (
      <div key={item.id}>
        <button
          onClick={() => {
            if (item.type === 'folder') {
              toggleFolder(item.id)
            }
            setSelectedItem(item.id)
          }}
          onDoubleClick={() => navigateToFolder(item)}
          className={`flex items-center gap-2 w-full px-2 py-1 rounded text-left hover:bg-secondary transition-colors ${
            selectedItem === item.id ? 'bg-secondary' : ''
          }`}
          style={{ paddingLeft: `${depth * 16 + 8}px` }}
        >
          {item.type === 'folder' && (
            <span className="w-4 h-4 flex items-center justify-center">
              {hasChildren && (
                isExpanded ? (
                  <ChevronDown className="h-3 w-3 text-muted-foreground" />
                ) : (
                  <ChevronRight className="h-3 w-3 text-muted-foreground" />
                )
              )}
            </span>
          )}
          <Icon className={`h-4 w-4 ${getIconColor(item.type)}`} />
          <span className="text-sm text-foreground truncate">{item.name}</span>
        </button>
        {item.type === 'folder' && isExpanded && item.children && (
          <div>
            {item.children.map(child => renderTreeItem(child, depth + 1))}
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="flex h-full bg-background">
      {/* Sidebar */}
      <div className="w-56 border-r border-border flex flex-col">
        {/* Quick access */}
        <div className="p-3">
          <h3 className="text-xs font-medium text-muted-foreground uppercase mb-2">
            Quick Access
          </h3>
          <div className="space-y-1">
            {quickAccess.map((item) => (
              <button
                key={item.name}
                onClick={() => setCurrentPath([item.name])}
                className="flex items-center gap-3 w-full px-2 py-1.5 rounded hover:bg-secondary transition-colors"
              >
                <item.icon className="h-4 w-4 text-primary" />
                <span className="text-sm text-foreground">{item.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Drives */}
        <div className="p-3 pt-0">
          <h3 className="text-xs font-medium text-muted-foreground uppercase mb-2">
            Drives
          </h3>
          <button className="flex items-center gap-3 w-full px-2 py-1.5 rounded hover:bg-secondary transition-colors">
            <HardDrive className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-foreground">Local Disk (C:)</span>
          </button>
        </div>

        {/* Tree view */}
        <div className="flex-1 p-3 pt-0 overflow-auto">
          <h3 className="text-xs font-medium text-muted-foreground uppercase mb-2">
            Folders
          </h3>
          <div className="space-y-0.5">
            {mockFileSystem.map(item => renderTreeItem(item))}
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col">
        {/* Toolbar */}
        <div className="flex items-center gap-2 p-2 border-b border-border">
          <button
            onClick={goBack}
            className="flex h-8 w-8 items-center justify-center rounded hover:bg-secondary transition-colors"
            disabled={currentPath.length <= 1}
          >
            <ArrowLeft className="h-4 w-4 text-muted-foreground" />
          </button>
          <button
            className="flex h-8 w-8 items-center justify-center rounded hover:bg-secondary transition-colors"
            disabled
          >
            <ArrowRight className="h-4 w-4 text-muted-foreground" />
          </button>
          <button
            onClick={goUp}
            className="flex h-8 w-8 items-center justify-center rounded hover:bg-secondary transition-colors"
            disabled={currentPath.length <= 1}
          >
            <ArrowUp className="h-4 w-4 text-muted-foreground" />
          </button>

          {/* Path bar */}
          <div className="flex-1 flex items-center gap-1 bg-secondary rounded px-3 py-1.5">
            {currentPath.map((part, i) => (
              <div key={i} className="flex items-center gap-1">
                {i > 0 && <ChevronRight className="h-3 w-3 text-muted-foreground" />}
                <button
                  onClick={() => setCurrentPath(currentPath.slice(0, i + 1))}
                  className="text-sm text-foreground hover:text-primary transition-colors"
                >
                  {part}
                </button>
              </div>
            ))}
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search"
              className="w-40 rounded bg-secondary pl-8 pr-3 py-1.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>

          {/* View toggle */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`flex h-8 w-8 items-center justify-center rounded transition-colors ${
                viewMode === 'grid' ? 'bg-secondary' : 'hover:bg-secondary'
              }`}
            >
              <Grid3X3 className="h-4 w-4 text-muted-foreground" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`flex h-8 w-8 items-center justify-center rounded transition-colors ${
                viewMode === 'list' ? 'bg-secondary' : 'hover:bg-secondary'
              }`}
            >
              <List className="h-4 w-4 text-muted-foreground" />
            </button>
          </div>
        </div>

        {/* Files */}
        <div className="flex-1 p-4 overflow-auto">
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-6 gap-4">
              {filteredFiles.map((item) => {
                const Icon = getIcon(item.type)
                return (
                  <button
                    key={item.id}
                    onClick={() => setSelectedItem(item.id)}
                    onDoubleClick={() => navigateToFolder(item)}
                    className={`flex flex-col items-center gap-2 p-3 rounded-lg transition-colors ${
                      selectedItem === item.id
                        ? 'bg-primary/20 ring-1 ring-primary'
                        : 'hover:bg-secondary'
                    }`}
                  >
                    <Icon className={`h-10 w-10 ${getIconColor(item.type)}`} />
                    <span className="text-xs text-foreground text-center truncate w-full">
                      {item.name}
                    </span>
                  </button>
                )
              })}
            </div>
          ) : (
            <div className="space-y-1">
              {/* Header */}
              <div className="flex items-center gap-4 px-3 py-2 text-xs font-medium text-muted-foreground border-b border-border">
                <span className="flex-1">Name</span>
                <span className="w-24">Modified</span>
                <span className="w-20 text-right">Size</span>
              </div>
              {filteredFiles.map((item) => {
                const Icon = getIcon(item.type)
                return (
                  <button
                    key={item.id}
                    onClick={() => setSelectedItem(item.id)}
                    onDoubleClick={() => navigateToFolder(item)}
                    className={`flex items-center gap-4 w-full px-3 py-2 rounded transition-colors ${
                      selectedItem === item.id
                        ? 'bg-primary/20 ring-1 ring-primary'
                        : 'hover:bg-secondary'
                    }`}
                  >
                    <div className="flex items-center gap-3 flex-1">
                      <Icon className={`h-5 w-5 ${getIconColor(item.type)}`} />
                      <span className="text-sm text-foreground truncate">
                        {item.name}
                      </span>
                    </div>
                    <span className="w-24 text-xs text-muted-foreground">
                      {item.modified || '-'}
                    </span>
                    <span className="w-20 text-xs text-muted-foreground text-right">
                      {item.size || '-'}
                    </span>
                  </button>
                )
              })}
            </div>
          )}

          {filteredFiles.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
              <Folder className="h-16 w-16 mb-4 opacity-50" />
              <p>This folder is empty</p>
            </div>
          )}
        </div>

        {/* Status bar */}
        <div className="flex items-center justify-between px-4 py-2 border-t border-border text-xs text-muted-foreground">
          <span>{filteredFiles.length} items</span>
          {selectedItem && <span>1 item selected</span>}
        </div>
      </div>
    </div>
  )
}
