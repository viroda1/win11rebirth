'use client'

import { useState, useRef, useEffect } from 'react'
import { useOSStore } from '@/lib/store'

interface TerminalLine {
  type: 'input' | 'output' | 'error'
  content: string
}

export function Terminal() {
  const { user } = useOSStore()
  const [lines, setLines] = useState<TerminalLine[]>([
    { type: 'output', content: 'Win11 Rebirth Terminal v1.0.0' },
    { type: 'output', content: 'Copyright (c) v/admin (viroda1). All rights reserved.' },
    { type: 'output', content: '' },
    { type: 'output', content: 'Type "help" for available commands.' },
    { type: 'output', content: '' },
  ])
  const [currentInput, setCurrentInput] = useState('')
  const [commandHistory, setCommandHistory] = useState<string[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const inputRef = useRef<HTMLInputElement>(null)
  const terminalRef = useRef<HTMLDivElement>(null)

  const username = user?.username?.toLowerCase().replace(/\s/g, '') || 'user'
  const prompt = `${username}@rebirth:~$`

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight
    }
  }, [lines])

  const processCommand = (cmd: string) => {
    const args = cmd.trim().split(' ')
    const command = args[0].toLowerCase()

    switch (command) {
      case '':
        return []
      
      case 'help':
        return [
          'Available commands:',
          '  help      - Show this help message',
          '  clear     - Clear the terminal',
          '  echo      - Print text to terminal',
          '  date      - Show current date and time',
          '  whoami    - Show current user',
          '  hostname  - Show system hostname',
          '  uname     - Show system information',
          '  ls        - List files (simulated)',
          '  pwd       - Print working directory',
          '  cat       - Display file contents (simulated)',
          '  neofetch  - Display system info',
          '  version   - Show Win11 Rebirth version',
          '  credits   - Show credits',
          '  exit      - Close terminal (use window controls)',
        ]
      
      case 'clear':
        setLines([])
        return []
      
      case 'echo':
        return [args.slice(1).join(' ')]
      
      case 'date':
        return [new Date().toString()]
      
      case 'whoami':
        return [user?.username || 'user']
      
      case 'hostname':
        return ['rebirth-desktop']
      
      case 'uname':
        if (args[1] === '-a') {
          return ['Win11Rebirth 1.0.0 rebirth-desktop x86_64 Web/JS']
        }
        return ['Win11Rebirth']
      
      case 'ls':
        return [
          'Desktop    Documents    Downloads    Music    Pictures    Videos',
        ]
      
      case 'pwd':
        return [`/home/${username}`]
      
      case 'cat':
        if (args[1] === 'readme.txt' || args[1] === 'README.txt') {
          return [
            'Welcome to Win11 Rebirth!',
            '',
            'This is a web-based Windows 11 experience.',
            'Created by v/admin (viroda1)',
            'Visit: https://vironexus.rf.gd',
          ]
        }
        return ['cat: No such file or directory']
      
      case 'neofetch':
        return [
          '       _____          ',
          '      /     \\         ' + username + '@rebirth',
          '     /   |   \\        -------------------',
          '    /    |    \\       OS: Win11 Rebirth 1.0.0',
          '   /     |     \\      Host: ViroNexus Web Platform',
          '  /______|______\\     Kernel: WebJS',
          '  \\      |      /     Shell: Rebirth Terminal',
          '   \\     |     /      Resolution: ' + (typeof window !== 'undefined' ? window.innerWidth + 'x' + window.innerHeight : '1920x1080'),
          '    \\    |    /       Theme: Purple',
          '     \\   |   /        Terminal: Win11 Rebirth Term',
          '      \\_____/         ',
          '                      ',
        ]
      
      case 'version':
        return [
          'Win11 Rebirth v1.0.0',
          'Build: 2024.03.15',
          'Developer: v/admin (viroda1)',
        ]
      
      case 'credits':
        return [
          '╔══════════════════════════════════════╗',
          '║         Win11 Rebirth Credits         ║',
          '╠══════════════════════════════════════╣',
          '║  Developer: v/admin (viroda1)         ║',
          '║  Website: vironexus.rf.gd             ║',
          '║  GitHub: github.com/viroda1           ║',
          '║                                       ║',
          '║  Built with:                          ║',
          '║  - Next.js                            ║',
          '║  - React                              ║',
          '║  - Tailwind CSS                       ║',
          '║  - TypeScript                         ║',
          '║  - Zustand                            ║',
          '╚══════════════════════════════════════╝',
        ]
      
      case 'sudo':
        return ['Nice try! But this is a web-based terminal 😄']
      
      case 'rm':
        if (args.includes('-rf') && args.includes('/')) {
          return ['Nice try! Your system is safe 😄']
        }
        return ['rm: Operation not permitted in this environment']
      
      case 'exit':
        return ['Use the window close button to exit the terminal.']
      
      default:
        return [`Command not found: ${command}. Type "help" for available commands.`]
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    const newLines: TerminalLine[] = [
      { type: 'input', content: `${prompt} ${currentInput}` },
    ]
    
    const output = processCommand(currentInput)
    output.forEach(line => {
      newLines.push({ type: 'output', content: line })
    })
    
    if (currentInput.trim()) {
      setCommandHistory(prev => [...prev, currentInput])
      setHistoryIndex(-1)
    }
    
    setLines(prev => [...prev, ...newLines])
    setCurrentInput('')
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault()
      if (commandHistory.length > 0) {
        const newIndex = historyIndex < commandHistory.length - 1 ? historyIndex + 1 : historyIndex
        setHistoryIndex(newIndex)
        setCurrentInput(commandHistory[commandHistory.length - 1 - newIndex])
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault()
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1
        setHistoryIndex(newIndex)
        setCurrentInput(commandHistory[commandHistory.length - 1 - newIndex])
      } else {
        setHistoryIndex(-1)
        setCurrentInput('')
      }
    }
  }

  const focusInput = () => {
    inputRef.current?.focus()
  }

  return (
    <div
      className="h-full bg-[#0c0c0c] font-mono text-sm overflow-hidden flex flex-col"
      onClick={focusInput}
    >
      <div
        ref={terminalRef}
        className="flex-1 p-4 overflow-auto"
      >
        {lines.map((line, i) => (
          <div
            key={i}
            className={`whitespace-pre-wrap ${
              line.type === 'error'
                ? 'text-red-400'
                : line.type === 'input'
                ? 'text-green-400'
                : 'text-gray-300'
            }`}
          >
            {line.content}
          </div>
        ))}
        
        {/* Current input line */}
        <form onSubmit={handleSubmit} className="flex">
          <span className="text-green-400">{prompt}</span>
          <input
            ref={inputRef}
            type="text"
            value={currentInput}
            onChange={(e) => setCurrentInput(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1 bg-transparent text-gray-300 outline-none ml-1 caret-gray-300"
            autoFocus
            spellCheck={false}
            autoComplete="off"
          />
        </form>
      </div>
    </div>
  )
}
