'use client'

import { useState } from 'react'
import {
  Grid3X3,
  LayoutGrid,
  Calendar,
  Heart,
  Trash2,
  Download,
  Share2,
  ZoomIn,
  ZoomOut,
  X,
  ChevronLeft,
  ChevronRight,
  Image,
} from 'lucide-react'

interface Photo {
  id: string
  title: string
  date: string
  color: string
}

const mockPhotos: Photo[] = [
  { id: '1', title: 'Sunset', date: '2024-03-15', color: 'from-orange-500 to-pink-500' },
  { id: '2', title: 'Mountains', date: '2024-03-14', color: 'from-blue-500 to-cyan-500' },
  { id: '3', title: 'City Lights', date: '2024-03-12', color: 'from-purple-500 to-pink-500' },
  { id: '4', title: 'Forest', date: '2024-03-10', color: 'from-green-500 to-emerald-500' },
  { id: '5', title: 'Ocean', date: '2024-03-08', color: 'from-blue-400 to-blue-600' },
  { id: '6', title: 'Desert', date: '2024-03-05', color: 'from-yellow-500 to-orange-500' },
  { id: '7', title: 'Northern Lights', date: '2024-03-01', color: 'from-green-400 to-purple-500' },
  { id: '8', title: 'Starry Night', date: '2024-02-28', color: 'from-indigo-900 to-purple-900' },
  { id: '9', title: 'Autumn', date: '2024-02-25', color: 'from-orange-400 to-red-500' },
  { id: '10', title: 'Winter', date: '2024-02-20', color: 'from-slate-300 to-blue-200' },
  { id: '11', title: 'Spring', date: '2024-02-15', color: 'from-pink-400 to-green-400' },
  { id: '12', title: 'Summer', date: '2024-02-10', color: 'from-yellow-400 to-orange-400' },
]

type ViewMode = 'grid' | 'timeline'

export function Photos() {
  const [viewMode, setViewMode] = useState<ViewMode>('grid')
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null)
  const [favorites, setFavorites] = useState<string[]>([])

  const toggleFavorite = (id: string) => {
    setFavorites(prev =>
      prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]
    )
  }

  const navigatePhoto = (direction: 'prev' | 'next') => {
    if (!selectedPhoto) return
    const currentIndex = mockPhotos.findIndex(p => p.id === selectedPhoto.id)
    if (direction === 'prev' && currentIndex > 0) {
      setSelectedPhoto(mockPhotos[currentIndex - 1])
    } else if (direction === 'next' && currentIndex < mockPhotos.length - 1) {
      setSelectedPhoto(mockPhotos[currentIndex + 1])
    }
  }

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <h1 className="text-xl font-semibold text-foreground">Photos</h1>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 rounded-lg transition-colors ${
              viewMode === 'grid' ? 'bg-secondary' : 'hover:bg-secondary'
            }`}
          >
            <Grid3X3 className="h-5 w-5 text-foreground" />
          </button>
          <button
            onClick={() => setViewMode('timeline')}
            className={`p-2 rounded-lg transition-colors ${
              viewMode === 'timeline' ? 'bg-secondary' : 'hover:bg-secondary'
            }`}
          >
            <Calendar className="h-5 w-5 text-foreground" />
          </button>
        </div>
      </div>

      {/* Sidebar and content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <div className="w-48 border-r border-border p-3 space-y-1">
          <button className="flex items-center gap-3 w-full px-3 py-2 rounded-lg bg-secondary text-foreground">
            <Image className="h-4 w-4" />
            <span className="text-sm">All Photos</span>
          </button>
          <button className="flex items-center gap-3 w-full px-3 py-2 rounded-lg hover:bg-secondary text-foreground transition-colors">
            <Heart className="h-4 w-4" />
            <span className="text-sm">Favorites</span>
            <span className="text-xs text-muted-foreground ml-auto">{favorites.length}</span>
          </button>
          <button className="flex items-center gap-3 w-full px-3 py-2 rounded-lg hover:bg-secondary text-foreground transition-colors">
            <Trash2 className="h-4 w-4" />
            <span className="text-sm">Deleted</span>
          </button>
        </div>

        {/* Photo grid */}
        <div className="flex-1 p-4 overflow-auto">
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-4 gap-3">
              {mockPhotos.map((photo) => (
                <button
                  key={photo.id}
                  onClick={() => setSelectedPhoto(photo)}
                  className="relative aspect-square rounded-lg overflow-hidden group"
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${photo.color}`} />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Image className="h-8 w-8 text-white/50" />
                  </div>
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      toggleFavorite(photo.id)
                    }}
                    className="absolute top-2 right-2 p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Heart
                      className={`h-5 w-5 ${
                        favorites.includes(photo.id)
                          ? 'fill-red-500 text-red-500'
                          : 'text-white'
                      }`}
                    />
                  </button>
                </button>
              ))}
            </div>
          ) : (
            <div className="space-y-6">
              {['March 2024', 'February 2024'].map((month) => (
                <div key={month}>
                  <h3 className="text-lg font-medium text-foreground mb-3">{month}</h3>
                  <div className="grid grid-cols-6 gap-2">
                    {mockPhotos
                      .filter(p => {
                        const photoMonth = new Date(p.date).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
                        return photoMonth === month
                      })
                      .map((photo) => (
                        <button
                          key={photo.id}
                          onClick={() => setSelectedPhoto(photo)}
                          className="relative aspect-square rounded-lg overflow-hidden group"
                        >
                          <div className={`absolute inset-0 bg-gradient-to-br ${photo.color}`} />
                          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
                        </button>
                      ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Lightbox */}
      {selectedPhoto && (
        <div className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center">
          {/* Close button */}
          <button
            onClick={() => setSelectedPhoto(null)}
            className="absolute top-4 right-4 p-2 text-white/70 hover:text-white transition-colors"
          >
            <X className="h-6 w-6" />
          </button>

          {/* Navigation */}
          <button
            onClick={() => navigatePhoto('prev')}
            className="absolute left-4 p-2 text-white/70 hover:text-white transition-colors"
          >
            <ChevronLeft className="h-8 w-8" />
          </button>
          <button
            onClick={() => navigatePhoto('next')}
            className="absolute right-4 p-2 text-white/70 hover:text-white transition-colors"
          >
            <ChevronRight className="h-8 w-8" />
          </button>

          {/* Photo */}
          <div className="max-w-4xl max-h-[80vh] aspect-video rounded-lg overflow-hidden">
            <div className={`w-full h-full bg-gradient-to-br ${selectedPhoto.color} flex items-center justify-center`}>
              <Image className="h-24 w-24 text-white/30" />
            </div>
          </div>

          {/* Info bar */}
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
            <div className="flex items-center justify-between max-w-4xl mx-auto">
              <div>
                <h3 className="text-lg font-medium text-white">{selectedPhoto.title}</h3>
                <p className="text-sm text-white/70">{selectedPhoto.date}</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => toggleFavorite(selectedPhoto.id)}
                  className="p-2 text-white/70 hover:text-white transition-colors"
                >
                  <Heart
                    className={`h-5 w-5 ${
                      favorites.includes(selectedPhoto.id) ? 'fill-red-500 text-red-500' : ''
                    }`}
                  />
                </button>
                <button className="p-2 text-white/70 hover:text-white transition-colors">
                  <Share2 className="h-5 w-5" />
                </button>
                <button className="p-2 text-white/70 hover:text-white transition-colors">
                  <Download className="h-5 w-5" />
                </button>
                <button className="p-2 text-white/70 hover:text-white transition-colors">
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
