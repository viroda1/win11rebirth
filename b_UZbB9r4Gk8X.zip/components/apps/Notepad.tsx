'use client'

import { useState } from 'react'
import { Save, FileText, Undo, Redo, Copy, Scissors, Clipboard } from 'lucide-react'

export function Notepad() {
  const [content, setContent] = useState('')
  const [fileName, setFileName] = useState('Untitled')
  const [saved, setSaved] = useState(true)
  const [wordCount, setWordCount] = useState(0)
  const [lineCount, setLineCount] = useState(1)

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const text = e.target.value
    setContent(text)
    setSaved(false)
    
    // Count words and lines
    const words = text.trim() ? text.trim().split(/\s+/).length : 0
    const lines = text.split('\n').length
    setWordCount(words)
    setLineCount(lines)
  }

  const handleSave = () => {
    // Create a blob and download
    const blob = new Blob([content], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${fileName}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    setSaved(true)
  }

  const handleNew = () => {
    if (!saved && content) {
      if (!confirm('You have unsaved changes. Create new file anyway?')) return
    }
    setContent('')
    setFileName('Untitled')
    setSaved(true)
    setWordCount(0)
    setLineCount(1)
  }

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Menu bar */}
      <div className="flex items-center gap-1 px-2 py-1 border-b border-border bg-card">
        <button className="px-3 py-1 text-sm text-foreground hover:bg-secondary rounded transition-colors">
          File
        </button>
        <button className="px-3 py-1 text-sm text-foreground hover:bg-secondary rounded transition-colors">
          Edit
        </button>
        <button className="px-3 py-1 text-sm text-foreground hover:bg-secondary rounded transition-colors">
          Format
        </button>
        <button className="px-3 py-1 text-sm text-foreground hover:bg-secondary rounded transition-colors">
          View
        </button>
        <button className="px-3 py-1 text-sm text-foreground hover:bg-secondary rounded transition-colors">
          Help
        </button>
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-1 px-2 py-1 border-b border-border bg-card">
        <button
          onClick={handleNew}
          className="flex items-center gap-2 px-2 py-1 text-sm text-foreground hover:bg-secondary rounded transition-colors"
          title="New"
        >
          <FileText className="h-4 w-4" />
        </button>
        <button
          onClick={handleSave}
          className="flex items-center gap-2 px-2 py-1 text-sm text-foreground hover:bg-secondary rounded transition-colors"
          title="Save"
        >
          <Save className="h-4 w-4" />
        </button>
        <div className="w-px h-5 bg-border mx-1" />
        <button
          className="flex items-center gap-2 px-2 py-1 text-sm text-muted-foreground hover:bg-secondary rounded transition-colors"
          title="Undo"
        >
          <Undo className="h-4 w-4" />
        </button>
        <button
          className="flex items-center gap-2 px-2 py-1 text-sm text-muted-foreground hover:bg-secondary rounded transition-colors"
          title="Redo"
        >
          <Redo className="h-4 w-4" />
        </button>
        <div className="w-px h-5 bg-border mx-1" />
        <button
          onClick={() => navigator.clipboard.writeText(window.getSelection()?.toString() || '')}
          className="flex items-center gap-2 px-2 py-1 text-sm text-foreground hover:bg-secondary rounded transition-colors"
          title="Copy"
        >
          <Copy className="h-4 w-4" />
        </button>
        <button
          className="flex items-center gap-2 px-2 py-1 text-sm text-foreground hover:bg-secondary rounded transition-colors"
          title="Cut"
        >
          <Scissors className="h-4 w-4" />
        </button>
        <button
          onClick={async () => {
            const text = await navigator.clipboard.readText()
            setContent(prev => prev + text)
          }}
          className="flex items-center gap-2 px-2 py-1 text-sm text-foreground hover:bg-secondary rounded transition-colors"
          title="Paste"
        >
          <Clipboard className="h-4 w-4" />
        </button>
      </div>

      {/* Editor */}
      <div className="flex-1 overflow-hidden">
        <textarea
          value={content}
          onChange={handleChange}
          className="w-full h-full p-4 bg-background text-foreground font-mono text-sm resize-none focus:outline-none"
          placeholder="Start typing..."
          spellCheck={false}
        />
      </div>

      {/* Status bar */}
      <div className="flex items-center justify-between px-4 py-1 border-t border-border bg-card text-xs text-muted-foreground">
        <div className="flex items-center gap-4">
          <span>
            {fileName}
            {!saved && ' •'}
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span>Lines: {lineCount}</span>
          <span>Words: {wordCount}</span>
          <span>Characters: {content.length}</span>
        </div>
      </div>
    </div>
  )
}
