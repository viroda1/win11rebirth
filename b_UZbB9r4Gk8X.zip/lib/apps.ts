export interface AppConfig {
  id: string
  title: string
  icon: string
  component: string
  category: 'system' | 'utility' | 'productivity' | 'entertainment'
  pinned?: boolean
}

export const apps: AppConfig[] = [
  {
    id: 'file-explorer',
    title: 'File Explorer',
    icon: 'folder',
    component: 'FileExplorer',
    category: 'system',
    pinned: true,
  },
  {
    id: 'browser',
    title: 'Rebirth Browser',
    icon: 'globe',
    component: 'Browser',
    category: 'productivity',
    pinned: true,
  },
  {
    id: 'settings',
    title: 'Settings',
    icon: 'settings',
    component: 'Settings',
    category: 'system',
    pinned: true,
  },
  {
    id: 'terminal',
    title: 'Terminal',
    icon: 'terminal',
    component: 'Terminal',
    category: 'utility',
    pinned: true,
  },
  {
    id: 'store',
    title: 'Rebirth Store',
    icon: 'store',
    component: 'Store',
    category: 'system',
    pinned: true,
  },
  {
    id: 'mail',
    title: 'Mail',
    icon: 'mail',
    component: 'Mail',
    category: 'productivity',
    pinned: true,
  },
  {
    id: 'notepad',
    title: 'Notepad',
    icon: 'file-text',
    component: 'Notepad',
    category: 'productivity',
  },
  {
    id: 'calculator',
    title: 'Calculator',
    icon: 'calculator',
    component: 'Calculator',
    category: 'utility',
  },
  {
    id: 'calendar',
    title: 'Calendar',
    icon: 'calendar',
    component: 'Calendar',
    category: 'productivity',
  },
  {
    id: 'weather',
    title: 'Weather',
    icon: 'cloud',
    component: 'Weather',
    category: 'utility',
  },
  {
    id: 'music',
    title: 'Music Player',
    icon: 'music',
    component: 'MusicPlayer',
    category: 'entertainment',
  },
  {
    id: 'photos',
    title: 'Photos',
    icon: 'image',
    component: 'Photos',
    category: 'entertainment',
  },
  {
    id: 'paint',
    title: 'Paint',
    icon: 'palette',
    component: 'Paint',
    category: 'entertainment',
  },
  {
    id: 'games',
    title: 'Games',
    icon: 'gamepad-2',
    component: 'Games',
    category: 'entertainment',
  },
  {
    id: 'about',
    title: 'About Rebirth',
    icon: 'info',
    component: 'About',
    category: 'system',
  },
]

export const getAppById = (id: string) => apps.find(app => app.id === id)
export const getAppsByCategory = (category: AppConfig['category']) => 
  apps.filter(app => app.category === category)
export const getPinnedApps = () => apps.filter(app => app.pinned)
