import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface Window {
  id: string
  title: string
  icon: string
  component: string
  isMinimized: boolean
  isMaximized: boolean
  position: { x: number; y: number }
  size: { width: number; height: number }
  zIndex: number
}

export interface User {
  username: string
  avatar: string
  theme: 'purple' | 'blue' | 'green' | 'pink'
  wallpaper: number
}

interface OSState {
  isLoggedIn: boolean
  isLocked: boolean
  user: User | null
  windows: Window[]
  activeWindowId: string | null
  startMenuOpen: boolean
  notificationCenterOpen: boolean
  searchOpen: boolean
  widgetsOpen: boolean
  nextZIndex: number
  volume: number
  brightness: number
  wifi: boolean
  bluetooth: boolean
  
  // Actions
  login: (username: string) => void
  logout: () => void
  lock: () => void
  unlock: () => void
  
  openWindow: (app: { id: string; title: string; icon: string; component: string }) => void
  closeWindow: (id: string) => void
  minimizeWindow: (id: string) => void
  maximizeWindow: (id: string) => void
  restoreWindow: (id: string) => void
  focusWindow: (id: string) => void
  updateWindowPosition: (id: string, position: { x: number; y: number }) => void
  updateWindowSize: (id: string, size: { width: number; height: number }) => void
  
  toggleStartMenu: () => void
  closeStartMenu: () => void
  toggleNotificationCenter: () => void
  closeNotificationCenter: () => void
  toggleSearch: () => void
  closeSearch: () => void
  toggleWidgets: () => void
  closeWidgets: () => void
  
  setVolume: (volume: number) => void
  setBrightness: (brightness: number) => void
  toggleWifi: () => void
  toggleBluetooth: () => void
  
  setTheme: (theme: User['theme']) => void
  setWallpaper: (wallpaper: number) => void
  setAvatar: (avatar: string) => void
}

export const useOSStore = create<OSState>()(
  persist(
    (set, get) => ({
      isLoggedIn: false,
      isLocked: true,
      user: null,
      windows: [],
      activeWindowId: null,
      startMenuOpen: false,
      notificationCenterOpen: false,
      searchOpen: false,
      widgetsOpen: false,
      nextZIndex: 1,
      volume: 75,
      brightness: 100,
      wifi: true,
      bluetooth: false,
      
      login: (username) => set({
        isLoggedIn: true,
        isLocked: false,
        user: {
          username,
          avatar: '👤',
          theme: 'purple',
          wallpaper: 0,
        }
      }),
      
      logout: () => set({
        isLoggedIn: false,
        isLocked: true,
        user: null,
        windows: [],
        activeWindowId: null,
        startMenuOpen: false,
        notificationCenterOpen: false,
      }),
      
      lock: () => set({ isLocked: true }),
      
      unlock: () => set({ isLocked: false }),
      
      openWindow: (app) => {
        const { windows, nextZIndex } = get()
        const existingWindow = windows.find(w => w.id === app.id)
        
        if (existingWindow) {
          if (existingWindow.isMinimized) {
            set({
              windows: windows.map(w =>
                w.id === app.id
                  ? { ...w, isMinimized: false, zIndex: nextZIndex }
                  : w
              ),
              activeWindowId: app.id,
              nextZIndex: nextZIndex + 1,
            })
          } else {
            get().focusWindow(app.id)
          }
          return
        }
        
        const newWindow: Window = {
          ...app,
          isMinimized: false,
          isMaximized: false,
          position: { x: 100 + (windows.length * 30), y: 50 + (windows.length * 30) },
          size: { width: 900, height: 600 },
          zIndex: nextZIndex,
        }
        
        set({
          windows: [...windows, newWindow],
          activeWindowId: app.id,
          nextZIndex: nextZIndex + 1,
          startMenuOpen: false,
        })
      },
      
      closeWindow: (id) => set(state => ({
        windows: state.windows.filter(w => w.id !== id),
        activeWindowId: state.activeWindowId === id ? null : state.activeWindowId,
      })),
      
      minimizeWindow: (id) => set(state => ({
        windows: state.windows.map(w =>
          w.id === id ? { ...w, isMinimized: true } : w
        ),
        activeWindowId: state.activeWindowId === id ? null : state.activeWindowId,
      })),
      
      maximizeWindow: (id) => set(state => ({
        windows: state.windows.map(w =>
          w.id === id ? { ...w, isMaximized: true } : w
        ),
      })),
      
      restoreWindow: (id) => set(state => ({
        windows: state.windows.map(w =>
          w.id === id ? { ...w, isMaximized: false } : w
        ),
      })),
      
      focusWindow: (id) => set(state => ({
        windows: state.windows.map(w =>
          w.id === id ? { ...w, zIndex: state.nextZIndex } : w
        ),
        activeWindowId: id,
        nextZIndex: state.nextZIndex + 1,
      })),
      
      updateWindowPosition: (id, position) => set(state => ({
        windows: state.windows.map(w =>
          w.id === id ? { ...w, position } : w
        ),
      })),
      
      updateWindowSize: (id, size) => set(state => ({
        windows: state.windows.map(w =>
          w.id === id ? { ...w, size } : w
        ),
      })),
      
      toggleStartMenu: () => set(state => ({
        startMenuOpen: !state.startMenuOpen,
        notificationCenterOpen: false,
        searchOpen: false,
        widgetsOpen: false,
      })),
      
      closeStartMenu: () => set({ startMenuOpen: false }),
      
      toggleNotificationCenter: () => set(state => ({
        notificationCenterOpen: !state.notificationCenterOpen,
        startMenuOpen: false,
        searchOpen: false,
        widgetsOpen: false,
      })),
      
      closeNotificationCenter: () => set({ notificationCenterOpen: false }),
      
      toggleSearch: () => set(state => ({
        searchOpen: !state.searchOpen,
        startMenuOpen: false,
        notificationCenterOpen: false,
        widgetsOpen: false,
      })),
      
      closeSearch: () => set({ searchOpen: false }),
      
      toggleWidgets: () => set(state => ({
        widgetsOpen: !state.widgetsOpen,
        startMenuOpen: false,
        notificationCenterOpen: false,
        searchOpen: false,
      })),
      
      closeWidgets: () => set({ widgetsOpen: false }),
      
      setVolume: (volume) => set({ volume }),
      setBrightness: (brightness) => set({ brightness }),
      toggleWifi: () => set(state => ({ wifi: !state.wifi })),
      toggleBluetooth: () => set(state => ({ bluetooth: !state.bluetooth })),
      
      setTheme: (theme) => set(state => ({
        user: state.user ? { ...state.user, theme } : null,
      })),
      
      setWallpaper: (wallpaper) => set(state => ({
        user: state.user ? { ...state.user, wallpaper } : null,
      })),
      
      setAvatar: (avatar) => set(state => ({
        user: state.user ? { ...state.user, avatar } : null,
      })),
    }),
    {
      name: 'win11-rebirth-storage',
      partialize: (state) => ({
        user: state.user,
        isLoggedIn: state.isLoggedIn,
      }),
    }
  )
)
