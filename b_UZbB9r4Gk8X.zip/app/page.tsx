'use client'

import { useOSStore } from '@/lib/store'
import { LoginScreen } from '@/components/os/LoginScreen'
import { Desktop } from '@/components/os/Desktop'

export default function Win11Rebirth() {
  const { isLoggedIn, isLocked } = useOSStore()

  if (!isLoggedIn || isLocked) {
    return <LoginScreen />
  }

  return <Desktop />
}
